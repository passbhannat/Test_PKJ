using General.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace General
{
    public class clsSendMail
    {
        public bool sendMail(string to, string from, string cc, string bcc, string sub, string body, string attachment, out string errorMessage)
        {
            errorMessage = string.Empty;
            System.Net.Mail.MailMessage Email = new System.Net.Mail.MailMessage();

            if (to != "")
            {
                Email.To.Add(to);
            }
            if (cc != "")
            {
                Email.CC.Add(cc);
            }
            if (bcc != "")
            {
                Email.Bcc.Add(bcc);
            }
            try
            {
                Email.Subject = sub;
                Email.IsBodyHtml = true;
                Email.Body = body;

                SmtpClient smtpClient = new SmtpClient();
                Email.From = new System.Net.Mail.MailAddress(ConfigManager.GetFromMail());
                smtpClient.Host = ConfigManager.GetSMTP_Host();
                smtpClient.Port = ConfigManager.GetSMTP_Port();
                smtpClient.UseDefaultCredentials = true;

                smtpClient.Credentials = new System.Net.NetworkCredential(ConfigManager.GetSMTP_Username(), ConfigManager.GetSMTP_Password());
                if (ConfigManager.GetSMTP_Host() == "smtp.gmail.com")
                {
                    smtpClient.EnableSsl = true;
                }
                smtpClient.EnableSsl = true;
                try
                {
                    smtpClient.Send(Email);
                }
                catch (SmtpFailedRecipientsException ex)
                {
                    errorMessage = ex.Message;
                    return false;
                }
            }
            catch (System.Net.Mail.SmtpException se)
            {
                errorMessage = se.Message;
                return false;
            }
            return true;
        }


        //public List<clsEntity_EmailTemplate> Get_EmailTemplate(int TemplateTriggerId, string dbName)
        //{
        //    clsSendMailDAL _dAL = new clsSendMailDAL();
        //    List<clsEntity_EmailTemplate> _clsEntity_EmailTemplate = _dAL.Get_EmailTemplate(TemplateTriggerId, dbName);
        //    return _clsEntity_EmailTemplate;
        //}
    }
}
