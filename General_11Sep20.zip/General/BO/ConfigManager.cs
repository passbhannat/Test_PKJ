﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace General.Classes
{
    public static class ConfigManager
    {


        public static string GetSMTP_Host()
        {
            return ConfigurationManager.AppSettings["SMTP_Host"].ToString();
        }


        public static string GetSMTP_Username()
        {
            return ConfigurationManager.AppSettings["SMTP_Username"].ToString();
        }

        public static string GetSMTP_Password()
        {
            return ConfigurationManager.AppSettings["SMTP_Password"].ToString();
        }

        public static int GetSMTP_Port()
        {
            return int.Parse(ConfigurationManager.AppSettings["SMTP_Port"].ToString());
        }

        public static string GetFromMail()
        {
            return ConfigurationManager.AppSettings["FromMail"].ToString();
        }
    }
}