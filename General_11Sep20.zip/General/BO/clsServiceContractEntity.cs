﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class clsServiceContractEntity
    {
        public string ContractId { get; set; }

        public string CardCode { get; set; }

        public string FatherCardCode { get; set; }

    }
}
