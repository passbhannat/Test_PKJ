using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using General.Classes;

namespace General
{
    class clsSalesOrder : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;

        Folder folderItem;
        private const int folderItemGroupDiscount_PaneLevel = 98;
        private const string folderItemGroupDiscountUID = "folderIGD";

        const string ItemGroupDiscountTable = "@CRD_ITMGRP_DISC";
        const string matrixItemGroupDiscount = "mtxIGD";
        const string matrixItemGroupDiscount_ItemGroupUID = "U_ItmGCod";
        const string matrixItemGroupDiscount_DiscPerUID = "U_DiscPer";
        const string matrixItemGroupDiscount_CardCodeUID = "U_CardCode";
        const string buttonItemGroupDiscountAddRow = "btAddRow";

        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;

        const string mainDBDataSource = "OITM";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == "38")
                            {
                                if (pVal.ColUID == "1")
                                {
                                    oForm = oApplication.Forms.GetFormByTypeAndCount(pVal.FormType, pVal.FormTypeCount);
                                    string cardCode = oForm.DataSources.DBDataSources.Item(0).GetValue("CardCode", 0).Trim();
                                    SAPbouiCOM.ChooseFromListCollection oCFLs = null;

                                    oCFLs = oForm.ChooseFromLists;

                                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                                    oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                                    string sCFL_ID = null;
                                    sCFL_ID = oCFLEvento.ChooseFromListUID;

                                    SAPbouiCOM.ChooseFromList oCFL = null;
                                    oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                                    SAPbouiCOM.DataTable oDataTable = null;
                                    oDataTable = oCFLEvento.SelectedObjects;
                                    if (oDataTable != null)
                                    {
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                        string itemCode = oDataTable.GetValue("ItemCode", 0).ToString();
                                        string itemGroup = oDataTable.GetValue(CommonFields.ItmsGrpCod, 0).ToString();
                                        //try
                                        //{
                                        //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row);
                                        //    oEdit.String = dblPrice.ToString();
                                        //}
                                        //catch { }
                                    }
                                }

                            }
                        }

                        #endregion

                        #region F_et_KEY_DOWN
                        else if (pVal.EventType == BoEventTypes.et_KEY_DOWN)
                        {
                            oForm = oApplication.Forms.GetFormByTypeAndCount(pVal.FormType, pVal.FormTypeCount);
                            if (pVal.ItemUID == "38")
                            {
                                if (pVal.ColUID == "1")
                                {
                                    if (pVal.CharPressed == 9)
                                    {
                                        string cardcode = oForm.DataSources.DBDataSources.Item(0).GetValue("CardCode", 0).Trim();
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                        string itemcode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", pVal.Row)).String;
                                        double price =  objclsCommon.GetPrice(cardcode, itemcode);
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", pVal.Row)).String = price.ToString();
                                    }
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion
    }
}
