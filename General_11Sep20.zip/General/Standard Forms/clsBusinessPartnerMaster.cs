using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using General.Classes;

namespace General
{
    class clsBusinessPartnerMaster : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;

        Folder folderItem;
        private const int folderItemGroupDiscount_PaneLevel = 98;
        private const string folderItemGroupDiscountUID = "folderIGD";

        const string ItemGroupDiscountTable = "@CRD_ITMGRP_DISC";
        const string matrixItemGroupDiscount = "mtxIGD";
        const string matrixItemGroupDiscount_ItemGroupUID = "U_ItmGCod";
        const string matrixItemGroupDiscount_DiscPerUID = "U_DiscPer";
        const string matrixItemGroupDiscount_CardCodeUID = "U_CardCode";
        const string buttonItemGroupDiscountAddRow = "btAddRow";

        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;

        const string mainDBDataSource = "OITM";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.BusinessPartner))
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            try
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific;
                            }
                            catch
                            {
                                CreateControls(oForm);
                            }
                        }

                        #endregion

                        #region F_et_ITEM_PRESSED

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            try
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (pVal.ItemUID == folderItemGroupDiscountUID)
                                {
                                    oForm.PaneLevel = folderItemGroupDiscount_PaneLevel;
                                }
                                else if (pVal.ItemUID == buttonItemGroupDiscountAddRow)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific;
                                    oMatrix.AddRow(1, oMatrix.VisualRowCount);
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText("F_et_ITEM_PRESSED Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region pVal.ItemChanged

                        if (pVal.ItemChanged)
                        {
                            try
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (pVal.ColUID == matrixItemGroupDiscount_DiscPerUID)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (pVal.Row == oMatrix.VisualRowCount)
                                    {
                                        oMatrix.AddRow(1, pVal.Row);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText("pVal.ItemChanged Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == "AddRow")
                    {
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtxCYP").Specific;
                        oMatrix.AddRow(1, oMatrix.VisualRowCount);
                    }
                    else if (pVal.MenuUID == "DeleteRow")
                    {
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtxCYP").Specific;
                        bool boolRowSelected = false;
                        for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                        {
                            if (oMatrix.IsRowSelected(i))
                            {
                                boolRowSelected = true;
                                oMatrix.DeleteRow(i);
                            }
                        }
                        if (boolRowSelected == false)
                        {
                            oApplication.StatusBar.SetText("No Row Selected.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string cardcode = oForm.DataSources.DBDataSources.Item(0).GetValue(CommonFields.CardCode, 0).Trim();
                        //RemoveEmptyRows(BusinessObjectInfo.FormUID, "mtxCYP", "combo", "FinYear");
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific;
                        if (oMatrix.VisualRowCount >= 1)
                        {
                            InsertItemGroupDiscountUDT(cardcode, oMatrix);
                        }

                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                        {
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific;
                            oMatrix.Clear();
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string cardcode = oForm.DataSources.DBDataSources.Item(0).GetValue(CommonFields.CardCode, 0).Trim();
                        try
                        {
                            oMatrix = ((SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific);
                        }
                        catch
                        {
                            CreateControls(oForm);
                        }
                        LoadItemGroupDiscountMatrix(BusinessObjectInfo.FormUID, cardcode);
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                        }
                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void CreateControls(SAPbouiCOM.Form oForm)
        {

            try
            {

                #region Add Tab

                baseItem = oForm.Items.Item("15");
                newItem = oForm.Items.Add(folderItemGroupDiscountUID, BoFormItemTypes.it_FOLDER);
                newItem.Top = baseItem.Top;
                newItem.Height = baseItem.Height;
                newItem.Left = baseItem.Left + baseItem.Width;
                newItem.Width = baseItem.Width;
                newItem.Visible = true;
                folderItem = (SAPbouiCOM.Folder)newItem.Specific;
                folderItem.Caption = "ItemGroup Discount";
                folderItem.GroupWith(baseItem.UniqueID);
                folderItem.Pane = folderItemGroupDiscount_PaneLevel;

                #endregion

                #region  Add Matrix In Tab

                oForm.DataSources.DBDataSources.Add(ItemGroupDiscountTable);

                #region Add Contract Details Matrix

                newItem = oForm.Items.Add(matrixItemGroupDiscount, BoFormItemTypes.it_MATRIX);
                newItem.FromPane = folderItemGroupDiscount_PaneLevel;
                newItem.ToPane = folderItemGroupDiscount_PaneLevel;
                //Attachment Matrix
                //baseItem = oForm.Items.Item("1320002082");
                baseItem = oForm.Items.Item("136");
                newItem.Top = baseItem.Top;
                newItem.Left = 10;
                newItem.Height = baseItem.Height;
                newItem.Width = baseItem.Width;

                oMatrix = (SAPbouiCOM.Matrix)newItem.Specific;
                oMatrix.SelectionMode = BoMatrixSelect.ms_Single;
                #endregion

                #region Add Columns Matrix

                oMatrix.Columns.Add("1", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                oColumns = oMatrix.Columns;

                oColumn = oColumns.Add(matrixItemGroupDiscount_ItemGroupUID, SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX);
                oColumn.TitleObject.Caption = "Item Group";
                oColumn.Width = 100;
                oColumn.Editable = true;
                oColumn.DisplayDesc = true;
                oColumn.DataBind.SetBound(true, ItemGroupDiscountTable, matrixItemGroupDiscount_ItemGroupUID);

                oColumn = oColumns.Add(matrixItemGroupDiscount_DiscPerUID, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                oColumn.TitleObject.Caption = "Percent";
                oColumn.Width = 100;
                oColumn.DataBind.SetBound(true, ItemGroupDiscountTable, matrixItemGroupDiscount_DiscPerUID);

                oColumns.Item("1").Editable = false;
                oMatrix.AddRow(1, 1);

                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixItemGroupDiscount_ItemGroupUID, 1);
                oCombo.ExpandType = BoExpandType.et_DescriptionOnly;
                //oCombo.DataBind.SetBound(true, mainDBDataSource, "U_FinYear");
                LoadItmGroup(oCombo);

                #endregion

                newItem = oForm.Items.Add(buttonItemGroupDiscountAddRow, BoFormItemTypes.it_BUTTON);
                newItem.FromPane = folderItemGroupDiscount_PaneLevel;
                newItem.ToPane = folderItemGroupDiscount_PaneLevel;
                //Attachment Matrix
                baseItem = oForm.Items.Item(matrixItemGroupDiscount);
                newItem.Top = baseItem.Top;
                newItem.Left = oForm.Items.Item("137").Left;
                newItem.Height = oForm.Items.Item("2").Height;
                newItem.Width = oForm.Items.Item("2").Width;
                SAPbouiCOM.Button oButton = newItem.Specific;
                oButton.Caption = "Add Row";
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("F_et_FORM_LOAD Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        private void LoadItmGroup(SAPbouiCOM.ComboBox cmb)
        {
            string query = $"SELECT \"" + CommonFields.ItmsGrpCod + "\",\"" + CommonFields.ItmsGrpNam + "\" FROM OITB ORDER BY \"" + CommonFields.ItmsGrpNam + "\" ";
            try
            {
                objclsCommon.FillCombo(cmb, query);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short);
            }
        }

        private void RemoveEmptyRows(string formUID, string matrixUID, string controlType, string primcolUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            for (int i = oMatrix.VisualRowCount; i > 0; i--)
            {
                try
                {
                    if (controlType == "combo")
                    {
                        if (((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(primcolUID, i)).Value.Trim() == string.Empty)
                        {
                            oMatrix.DeleteRow(i);
                        }
                    }
                    else
                    {
                        if (((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(primcolUID, i)).String.Trim() == string.Empty)
                        {
                            oMatrix.DeleteRow(i);

                        }
                    }
                }
                catch { }
            }
        }

        private void AddUpdateContractDetailsMatrix(string formUID, string itemcode, string finYear)
        {
            string code = itemcode + finYear;
            SAPbobsCOM.GeneralService oGeneralService;
            SAPbobsCOM.GeneralData oGeneralData;
            SAPbobsCOM.CompanyService oCmpSrv;
            SAPbobsCOM.GeneralData oDocLineGeneralData;
            SAPbobsCOM.GeneralDataParams oGeneralParams = null;
            StringBuilder sbQuery = new StringBuilder();
            try
            {
                oCmpSrv = (SAPbobsCOM.CompanyService)oCompany.GetCompanyService();
                oGeneralService = (SAPbobsCOM.GeneralService)oCmpSrv.GetGeneralService("ITM_CD");
                oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                oDocLineGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);

                sbQuery.Append("select 1 from [@ITM_CD] where CODE = '" + code + "' ");
                string isExist = objclsCommon.SelectRecord(sbQuery.ToString());

                oForm = oApplication.Forms.Item(formUID);
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtxCD").Specific;

                #region Add New Scheme

                if (isExist == string.Empty)
                {

                    try
                    {
                        oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                        oDocLineGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                        SAPbobsCOM.GeneralDataCollection oDocLinesCollection = (SAPbobsCOM.GeneralDataCollection)oGeneralData.Child("ITM_CD1");
                        oGeneralData.SetProperty("Code", code.ToString());
                        oGeneralData.SetProperty("Name", code.ToString());
                        oGeneralData.SetProperty("U_ItemCode", itemcode);
                        oGeneralData.SetProperty("U_FinYear", finYear);


                        if (oMatrix.RowCount > 0)
                        {

                            for (int i = 1; i <= oMatrix.RowCount; i++)
                            {
                                oDocLineGeneralData = oDocLinesCollection.Add();

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("Month", i)));
                                oDocLineGeneralData.SetProperty("U_Month", oEdit.Value);

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("PurRate", i)));
                                oDocLineGeneralData.SetProperty("U_PurRate", oEdit.Value);

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("SalRate", i)));
                                oDocLineGeneralData.SetProperty("U_SalRate", oEdit.Value);

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("ExPB", i)));
                                oDocLineGeneralData.SetProperty("U_ExPB", oEdit.Value);
                            }
                        }

                        oGeneralParams = oGeneralService.Add(oGeneralData);

                    }
                    catch (Exception ex)
                    {
                        oApplication.SetStatusBarMessage("Add Update Matrix - " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                    }
                }

                #endregion

                #region Update Existing schems

                else
                {

                    try
                    {
                        sbQuery.Length = 0;
                        sbQuery.Append("DELETE from [@ITM_CD1] where CODE = '" + code + "' ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
                        oGeneralParams.SetProperty("Code", code);
                        oGeneralData = oGeneralService.GetByParams(oGeneralParams);

                        SAPbobsCOM.GeneralDataCollection oChildTableRows; ;

                        if (oMatrix.RowCount > 0)
                        {
                            SAPbobsCOM.GeneralData oChildTableRow = null;
                            oChildTableRows = oGeneralData.Child("ITM_CD1");

                            for (int i = 1; i <= oMatrix.RowCount; i++)
                            {

                                oChildTableRow = oChildTableRows.Add();

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("Month", i)));
                                oChildTableRows.Item(i - 1).SetProperty("U_Month", oEdit.Value);

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("PurRate", i)));
                                oChildTableRows.Item(i - 1).SetProperty("U_PurRate", oEdit.Value);

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("SalRate", i)));
                                oChildTableRows.Item(i - 1).SetProperty("U_SalRate", oEdit.Value);

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("ExPB", i)));
                                oChildTableRows.Item(i - 1).SetProperty("U_ExPB", oEdit.Value);
                            }
                        }
                        oGeneralService.Update(oGeneralData);
                    }
                    catch (Exception ex)
                    {
                        oApplication.SetStatusBarMessage("Update -" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                    }
                }

                #endregion


            }
            catch (Exception e)
            {
                oApplication.SetStatusBarMessage("Add Update Matrix - " + e.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
        }


        private void FillContractYearMatrix(SAPbouiCOM.Form oForm, string stDate, string enDate)
        {

            string query = $"SELECT Code,U_FinYear FROM [@FINYEAR] WHERE  U_StDate>= '" + stDate + "' AND U_EnDate<='" + enDate + "'";

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtxCYP").Specific;
            oMatrix.Clear();
            int row = 0;

            oRs = objclsCommon.returnRecord(query.ToString());

            while (!oRs.EoF)
            {
                if (row <= oRs.RecordCount - 1)
                {
                    oMatrix.AddRow(1, oMatrix.VisualRowCount);
                }
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("FinYear", row + 1);
                oCombo.Select(oRs.Fields.Item("Code").Value.ToString(), BoSearchKey.psk_ByValue);
                row++;
                oRs.MoveNext();
            }

        }

        private void InsertItemGroupDiscountUDT(string cardcode, SAPbouiCOM.Matrix oMatrix)
        {
            objclsCommon.SelectRecord("DELETE FROM \"" + ItemGroupDiscountTable + "\" WHERE \"" + matrixItemGroupDiscount_CardCodeUID + "\" = '" + cardcode + "' ");
            for (int i = 1; i <= oMatrix.VisualRowCount; i++)
            {
                try
                {
                    string itemGroup = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixItemGroupDiscount_ItemGroupUID, i)).Value.Trim();
                    if (itemGroup == string.Empty)
                    {
                        continue;
                    }
                    SAPbobsCOM.UserTable oUserTable;
                    oUserTable = oCompany.UserTables.Item(ItemGroupDiscountTable.Replace("@", ""));
                    string code = objclsCommon.SelectRecord("SELECT Max(Cast(\"Code\" AS numeric(19,2)))  FROM \"" + ItemGroupDiscountTable + "\"");
                    double dblCode = code == string.Empty ? 0 : double.Parse(code) + 1;
                    oUserTable.Code = dblCode.ToString();
                    oUserTable.Name = dblCode.ToString();

                    oUserTable.UserFields.Fields.Item(matrixItemGroupDiscount_CardCodeUID).Value = cardcode;
                    oUserTable.UserFields.Fields.Item(matrixItemGroupDiscount_ItemGroupUID).Value = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixItemGroupDiscount_ItemGroupUID, i)).Value.Trim();
                    oUserTable.UserFields.Fields.Item(matrixItemGroupDiscount_DiscPerUID).Value = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemGroupDiscount_DiscPerUID, i)).String;
                    oUserTable.Add();
                }
                catch (Exception ex)
                {

                }
            }
        }


        private void AddUpdateContractYearPercentMatrix(string formUID, string code)
        {
            SAPbobsCOM.GeneralService oGeneralService;
            SAPbobsCOM.GeneralData oGeneralData;
            SAPbobsCOM.CompanyService oCmpSrv;
            SAPbobsCOM.GeneralData oDocLineGeneralData;
            SAPbobsCOM.GeneralDataParams oGeneralParams = null;
            StringBuilder sbQuery = new StringBuilder();
            try
            {
                oCmpSrv = (SAPbobsCOM.CompanyService)oCompany.GetCompanyService();
                oGeneralService = (SAPbobsCOM.GeneralService)oCmpSrv.GetGeneralService("ITM_CYP");
                oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                oDocLineGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);

                sbQuery.Append("select 1 from [@ITM_CYP] where CODE = '" + code + "' ");
                string isExist = objclsCommon.SelectRecord(sbQuery.ToString());

                oForm = oApplication.Forms.Item(formUID);
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtxCYP").Specific;

                #region Add New Scheme

                if (isExist == string.Empty)
                {

                    try
                    {
                        oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                        oDocLineGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
                        SAPbobsCOM.GeneralDataCollection oDocLinesCollection = (SAPbobsCOM.GeneralDataCollection)oGeneralData.Child("ITM_CYP1");
                        oGeneralData.SetProperty("Code", code.ToString());
                        oGeneralData.SetProperty("Name", code.ToString());

                        if (oMatrix.RowCount > 0)
                        {

                            for (int i = 1; i <= oMatrix.RowCount; i++)
                            {
                                oDocLineGeneralData = oDocLinesCollection.Add();

                                oCombo = ((SAPbouiCOM.ComboBox)(oMatrix.GetCellSpecific("FinYear", i)));
                                oDocLineGeneralData.SetProperty("U_FinYear", oCombo.Value.Trim());

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("Per", i)));
                                oDocLineGeneralData.SetProperty("U_Per", oEdit.Value);

                            }
                        }

                        oGeneralParams = oGeneralService.Add(oGeneralData);

                    }
                    catch (Exception ex)
                    {
                        oApplication.SetStatusBarMessage("Add Update Matrix - " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                    }
                }

                #endregion

                #region Update Existing schems

                else
                {

                    try
                    {
                        sbQuery.Length = 0;
                        sbQuery.Append("DELETE from [@ITM_CYP1] where CODE = '" + code + "' ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
                        oGeneralParams.SetProperty("Code", code);
                        oGeneralData = oGeneralService.GetByParams(oGeneralParams);

                        SAPbobsCOM.GeneralDataCollection oChildTableRows = oGeneralData.Child("ITM_CYP1");

                        if (oMatrix.RowCount > 0)
                        {
                            SAPbobsCOM.GeneralData oChildTableRow = null;
                            oChildTableRows = oGeneralData.Child("ITM_CYP1");

                            for (int i = 1; i <= oMatrix.RowCount; i++)
                            {

                                oChildTableRow = oChildTableRows.Add();

                                oCombo = ((SAPbouiCOM.ComboBox)(oMatrix.GetCellSpecific("FinYear", i)));
                                oChildTableRows.Item(i - 1).SetProperty("U_FinYear", oCombo.Value.Trim());

                                oEdit = ((SAPbouiCOM.EditText)(oMatrix.GetCellSpecific("Per", i)));
                                oChildTableRows.Item(i - 1).SetProperty("U_Per", oEdit.Value);

                            }
                        }
                        oGeneralService.Update(oGeneralData);
                    }
                    catch (Exception ex)
                    {
                        oApplication.SetStatusBarMessage("Update -" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
                    }
                }

                #endregion


            }
            catch (Exception e)
            {
                oApplication.SetStatusBarMessage("Add Update Matrix - " + e.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
        }

        private void LoadItemGroupDiscountMatrix(string formUID, string code)
        {
            sbQuery.Length = 0;
            sbQuery.Append(" SELECT \"" + matrixItemGroupDiscount_ItemGroupUID + "\",\"" + matrixItemGroupDiscount_DiscPerUID + "\" FROM \"" + ItemGroupDiscountTable + "\" WHERE \"U_CardCode\" ='" + code + "'");

            try
            {
                int row = 0;
                oForm = oApplication.Forms.Item(formUID);
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItemGroupDiscount).Specific;
                oMatrix.Clear();
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                while (!oRs.EoF)
                {
                    if (row <= oRs.RecordCount - 1)
                    {
                        oMatrix.AddRow(1, row + 1);
                    }

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixItemGroupDiscount_ItemGroupUID, row + 1);
                    oCombo.Select(oRs.Fields.Item(matrixItemGroupDiscount_ItemGroupUID).Value.ToString(), BoSearchKey.psk_ByValue);

                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemGroupDiscount_DiscPerUID, row + 1);
                    oEdit.Value = oRs.Fields.Item(matrixItemGroupDiscount_DiscPerUID).Value.ToString();

                    row++;
                    oRs.MoveNext();
                }

                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, BoMessageTime.bmt_Short);
            }
            finally
            {
                objclsCommon.ReleaseObject(oRs);
            }
        }

        #endregion
    }
}
