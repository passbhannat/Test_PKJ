using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Microsoft.Win32.SafeHandles;
using System.IO;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace General
{
    class clsServiceContractList_SendMail : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string frDate = "frDate";
        const string toDate = "toDate";

        const string buttonExecute = "btExec";
        const string buttonFillData = "btFill";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Execute
                            if (pVal.ItemUID == buttonExecute)
                            {
                                mail();
                                return;
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsServiceContractEntity> list = new List<clsServiceContractEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Select", i) == "Y")
                                    {
                                        list.Add(new clsServiceContractEntity()
                                        {
                                            ContractId = oDT.GetValue("Contract No", i).ToString(),
                                            FatherCardCode = oDT.GetValue("FatherCard", i).ToString()
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                //var listDistnctFather = list.Select(o => o.FatherCardCode).Distinct();
                                var listDistnctFather = list.GroupBy(x => x.FatherCardCode).Select(y => y.Key).ToList();

                                for (int i = 0; i < listDistnctFather.Count; i++)
                                {
                                    var listContract = list.Where(x => x.FatherCardCode == listDistnctFather[i].ToString()).Select(n => n.ContractId).ToList();
                                    string contractID = string.Join<string>(",", listContract);
                                    SendContract(contractID, listDistnctFather[i].ToString());
                                }
                                //FillGrid();
                                //int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                //string itemCode = oForm.DataSources.UserDataSources.Item(CommonFields.ItemCode).Value.ToString();
                                //sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT \"U_TareWgt\",\"U_Gr_Wt\"");
                                //sbQuery.Append(" FROM " + CommonTables.ItemMasterData + " T0");
                                //sbQuery.Append(" WHERE \"" + CommonFields.ItemCode + "\" ='" + itemCode + "' ");

                                //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                //string tareWt = oRs.Fields.Item("U_TareWgt").Value.ToString();
                                //string grWt = oRs.Fields.Item("U_Gr_Wt").Value.ToString();

                            }
                            #endregion

                            #region Fill Data
                            if (pVal.ItemUID == buttonFillData)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                FillGrid();
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal)
        {
            if (pVal.BeforeAction == false)
            {
                if (pVal.MenuUID == SAPCustomFormUIDEnum.SERCONTLIST_SMAIL.ToString())
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        #endregion

        #region Method

        public void LoadForm(string formMenuID)
        {
            //string rowNo, string jbDocEntry, string productCode,string qcType;
            objclsComman.LoadXML(formMenuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Add(frDate, SAPbouiCOM.BoDataType.dt_DATE, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(frDate).Specific;
            oEdit.DataBind.SetBound(true, "", frDate);

            oForm.DataSources.UserDataSources.Add(toDate, SAPbouiCOM.BoDataType.dt_DATE, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(toDate).Specific;
            oEdit.DataBind.SetBound(true, "", toDate);

            FillGrid();

            //oForm.DataSources.UserDataSources.Add(CommonFields.ItemCode, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.ItemCode).Specific;
            //oEdit.DataBind.SetBound(true, "", CommonFields.ItemCode);
            //oEdit.String = productCode;
            //FillGrid(jbDocEntry, productCode, qcType);
        }

        private void FillGrid()
        {
            oForm = oApplication.Forms.ActiveForm;
            //DateTime fromDate;
            //DateTime toDate;
            //objclsComman.GetQuarterFromAndToDate(DateTime.Now, out fromDate, out toDate);
            //string sapFromDate = objclsComman.ConvertDateToSAPDateFormat(fromDate);
            //string sapToDate = objclsComman.ConvertDateToSAPDateFormat(toDate);

            string sapFromDate = oForm.DataSources.UserDataSources.Item(frDate).ValueEx;
            string sapToDate = oForm.DataSources.UserDataSources.Item(toDate).ValueEx;
            sbQuery.Length = 0;

            sbQuery.Append(" SELECT 'Y' \"Select\", T0.\"ContractID\" AS \"Contract No\", T0.\"CstmrCode\" AS \"Business Partner Code\", T0.\"CstmrName\" AS \"Business Partner Name\", ");
            sbQuery.Append(" T0.\"CntrcType\"  AS \"Contract Type\",T0.\"Status\", T0.\"StartDate\", T0.\"EndDate\", T0.\"Descriptio\", T2.\"FatherCard\"    ");
            sbQuery.Append(" FROM OCTR T0");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"ContractID\"= T1.\"ContractID\"");
            sbQuery.Append(" INNER JOIN OCRD T2 ON T0.\"CstmrCode\"= T2.\"CardCode\"");
            sbQuery.Append(" WHERE ");
            sbQuery.Append(" (T1.\"U_\" >= '" + sapToDate + "') AND ");
            sbQuery.Append(" (T1.\"U_Renewaldate\" >= '" + sapFromDate + "' AND T1.\"U_Renewaldate\" <= '" + sapToDate + "') AND ");
            sbQuery.Append(" (IFNULL(T1.\"TermDate\",'20990101') >= '" + sapToDate + "')  ");

            //sbQuery.Append(" NOT EXISTS ");
            //sbQuery.Append(" ( SELECT 1 FROM OINV IT0 ");
            //sbQuery.Append(" WHERE IT0.\"U_ContrNo\" = T0.\"ContractID\") ");
            sbQuery.Append(" GROUP BY ");
            sbQuery.Append(" T0.\"ContractID\" , T0.\"CstmrCode\", T0.\"CstmrName\", ");
            sbQuery.Append(" T0.\"CntrcType\"   ,T0.\"Status\", T0.\"StartDate\", T0.\"EndDate\", T0.\"Descriptio\" , T2.\"FatherCard\"  ");


            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
            SAPbouiCOM.EditTextColumn oEditCol;
            oEditCol = ((SAPbouiCOM.EditTextColumn)(oGrid.Columns.Item(1)));
            oEditCol.LinkedObjectType = "190";
            oEditCol = ((SAPbouiCOM.EditTextColumn)(oGrid.Columns.Item(2)));
            oEditCol.LinkedObjectType = "2";


        }

        public bool SendContract(string contractId, string fatherCode)
        {
            oApplication.StatusBar.SetText("Please wait sending mail against contract id: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

            string sapFromDate = oForm.DataSources.UserDataSources.Item(frDate).ValueEx;
            string sapToDate = oForm.DataSources.UserDataSources.Item(toDate).ValueEx;
            sbQuery.Length = 0;
            sbQuery.Append(" SELECT 'Y' \"Select\", T0.\"ContractID\" , T0.\"CstmrCode\" AS \"Business Partner Code\", T0.\"CstmrName\" AS \"Business Partner Name\", ");
            sbQuery.Append(" T1.\"U_ItemCode\", T2.\"FatherCard\",    ");
            sbQuery.Append(" T1.\"U_Ordernumber\", T1.\"U_Renewaldate\" ,   ");
            sbQuery.Append(" ROW_NUMBER() OVER (PARTITION BY T0.\"ContractID\" ORDER BY T1.\"U_ItemCode\") \"LineNo\"    ");

            sbQuery.Append(" FROM OCTR T0");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"ContractID\"= T1.\"ContractID\"");
            sbQuery.Append(" INNER JOIN OCRD T2 ON T0.\"CstmrCode\"= T2.\"CardCode\"");
            sbQuery.Append(" WHERE ");
            sbQuery.Append(" T0.\"ContractID\"  IN (" + contractId + ") AND ");
            sbQuery.Append(" (T1.\"U_Renewaldate\" >= '" + sapFromDate + "' AND T1.\"U_Renewaldate\" <= '" + sapToDate + "') AND ");
            sbQuery.Append(" (IFNULL(T1.\"TermDate\",'20990101') >= '" + sapToDate + "')  ");

            SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());

            StringBuilder sbBody = new StringBuilder();

            sbBody.AppendLine("<p>Dear Sir/Madam, ");
            sbBody.AppendLine("</p>");
            sbBody.AppendLine("<p>Please check contract details. ");
            sbBody.AppendLine("</p>");
            sbBody.AppendLine("<table border=" + 1 + " cellpadding=" + 0 + " cellspacing=" + 0 + " width = " + 400 + ">");

            sbBody.AppendLine("<tr bgcolor='#4da6ff'><td><b>Order No</b></td><td> <b>Line No </b> </td><td> <b> Item No</b> </td><td> <b> Quantity No</b> </td><td> <b> Renewal Date</b> </td></tr>");
            string toMail = objclsComman.SelectRecord("SELECT \"E_Mail\" FROM OCRD WHERE \"CardCode\" = '" + fatherCode + "'");

            while (!oRs.EoF)
            {
                //string orderNo = oRs.Fields.Item("U_Ordernumber").Value;
                string orderNo = oRs.Fields.Item("ContractID").Value.ToString();
                string lineNo = oRs.Fields.Item("LineNo").Value.ToString();
                string itemNo = oRs.Fields.Item("U_ItemCode").Value;
                string qty = "1";
                string renewalqtyDate = Convert.ToDateTime(oRs.Fields.Item("U_Renewaldate").Value).ToShortDateString();
                sbBody.AppendLine("<tr>");
                sbBody.AppendLine("<td align ='center'>" + orderNo + "</td> <td align ='center'>" + lineNo + "  </td><td align ='center' >" + itemNo + "  </td>");
                sbBody.AppendLine("<td align ='center'>" + qty + "</td> <td align ='center'>" + renewalqtyDate + "  </td>");
                sbBody.AppendLine("</tr>");

                oRs.MoveNext();
            }

            sbBody.AppendLine("</table>");

            sbBody.AppendLine("<p>");
            sbBody.AppendLine("Regards,");
            sbBody.AppendLine("</p>");
            sbBody.AppendLine("<p>");
            sbBody.AppendLine("Web Administrator");
            sbBody.AppendLine("</p>");

            //if (isFatherCardExists == string.Empty)
            //{
            //    oApplication.StatusBar.SetText("Consolidated BP is not defined", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            //    return false; ;
            //}
            SendMail(sbBody.ToString(), toMail);
            return true;
        }

        private void SendMail(string body, string toMail)
        {
            clsSendMail objclsSendMail = new clsSendMail();
            string fromMail = ConfigManager.GetSMTP_Username();
            string ccMail = "";
            string bccMail = "";
            string subject = "Contract Details";
            string attachment = "";
            string errorMessage = "";
            bool sendSuccess = objclsSendMail.sendMail(toMail, fromMail, ccMail, bccMail, subject, body, attachment, out errorMessage);
            if (sendSuccess == false)
            {

            }
        }

        private void mail()
        {
            string firstName = "Pravin";
            string lastName = "Ghadge";
            string apiKey = "130e71f1e2c43f5660029b21f0c70c4d-us17";

            var subscribeRequest = new
            {
                email_address = "pravinaug17@gmail.com",
                status = "subscribed",
                merge_fields = new
                {
                    FNAME = firstName,
                    LNAME = lastName
                }
            };
            var requestJson = JsonConvert.SerializeObject(subscribeRequest);
            CallMailChimpApi("lists/{listid}/members/", requestJson, apiKey);
        }

        private string CallMailChimpApi(string method, string requestJson, string key)
        {
            //method = "lists";
            var listId = "Sales";//"6b414de31f";
            var endpoint = String.Format("https://{0}.api.mailchimp.com/3.0/lists/{1}/members/", "us17", listId);
            byte[] dataStream = Encoding.UTF8.GetBytes(requestJson);
            var responsetext = string.Empty;
            WebRequest request = HttpWebRequest.Create(endpoint);
            WebResponse response = null;
            try
            {
                request.ContentType = "application/json";
                SetBasicAuthHeader(request, "IntenziveIVS", "Ras00Fl,");  // BASIC AUTH in place of Ras00Fl, key was there
             
                request.Method = "POST";
                request.ContentLength = dataStream.Length;
                Stream newstream = request.GetRequestStream();

                newstream.Write(dataStream, 0, dataStream.Length);
                newstream.Close();

                response = request.GetResponse();

                // get the result
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    JsonSerializer json = new JsonSerializer();
                    JObject content = JObject.Parse(reader.ReadToEnd());

                    responsetext = reader.ReadToEnd();
                }

                response.Close();
            }

            catch (WebException ex)
            {
                using (var sr = new StreamReader(response.GetResponseStream()))
                {
                    responsetext = sr.ReadToEnd();
                }
            }
            return responsetext;
        }

        public void SetBasicAuthHeader(WebRequest request, string username, string password)
        {
            string auth = username + ":" + password;
            auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth));
            request.Headers["Authorization"] = "Basic " + auth;
        }

        #endregion
    }
}