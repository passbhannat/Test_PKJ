using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Microsoft.Win32.SafeHandles;

namespace General
{
    class clsServiceContractList_PriceUpdate : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string rowNoUID = "RowNo";
        const string buttonPriceUpdate = "btPrUpd";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Price Update
                            if (pVal.ItemUID == buttonPriceUpdate)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsServiceContractEntity> list = new List<clsServiceContractEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Select", i) == "Y")
                                    {
                                        //if (oDT.GetValue("Fixed Price", i).ToString() == "Y")
                                        //{
                                        //    oApplication.StatusBar.SetText("You can't update fixed price service contract", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        //    return;
                                        //}
                                        list.Add(new clsServiceContractEntity()
                                        {
                                            ContractId = oDT.GetValue("Contract No", i).ToString(),
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                for (int i = 0; i < list.Count; i++)
                                {
                                    UpdateServiceContract(list[i].ContractId);
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal)
        {
            if (pVal.BeforeAction == false)
            {
                if (pVal.MenuUID == SAPCustomFormUIDEnum.SERCONTLIST_PRICE.ToString())
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        #endregion

        #region Method

        public void LoadForm(string formMenuID)
        {
            //string rowNo, string jbDocEntry, string productCode,string qcType;
            objclsComman.LoadXML(formMenuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            FillGrid();
            //oForm.DataSources.UserDataSources.Add("RowNo", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(rowNoUID).Specific;
            //oEdit.DataBind.SetBound(true, "", rowNoUID);
            //oEdit.String = rowNo;

            //oForm.DataSources.UserDataSources.Add(CommonFields.ItemCode, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.ItemCode).Specific;
            //oEdit.DataBind.SetBound(true, "", CommonFields.ItemCode);
            //oEdit.String = productCode;
            //FillGrid(jbDocEntry, productCode, qcType);
        }

        private void FillGrid()
        {
            oForm = oApplication.Forms.ActiveForm;

            sbQuery.Length = 0;

            sbQuery.Append(" SELECT 'Y' \"Select\", T0.\"ContractID\" AS \"Contract No\", T0.\"CstmrCode\" AS \"Business Partner Code\", T0.\"CstmrName\" AS \"Business Partner Name\", ");
            sbQuery.Append(" T0.\"CntrcType\"  AS \"Contract Type\",T0.\"Status\", T0.\"StartDate\", T0.\"EndDate\", T0.\"Descriptio\"   ");
            sbQuery.Append(" FROM OCTR T0");
            sbQuery.Append(" WHERE (T0.\"TermDate\" >= CURRENT_DATE OR IFNULL(T0.\"TermDate\",'') = '' ) AND IFNULL(T0.\"U_IsFixPr\",'N') = 'N' AND ");
            sbQuery.Append(" NOT EXISTS ");
            sbQuery.Append(" ( SELECT 1 FROM OINV IT0 ");
            sbQuery.Append(" WHERE IT0.\"U_ContrNo\" = T0.\"ContractID\") ");

            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
            }
            oGrid.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
            SAPbouiCOM.EditTextColumn oEditCol;
            oEditCol = ((SAPbouiCOM.EditTextColumn)(oGrid.Columns.Item(1)));
            oEditCol.LinkedObjectType = "190";
            oEditCol = ((SAPbouiCOM.EditTextColumn)(oGrid.Columns.Item(2)));
            oEditCol.LinkedObjectType = "2";
        }

        public bool AddInvoice(string contractId)
        {
            oApplication.StatusBar.SetText("Please wait creating invoice against contract id: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            sbQuery.Length = 0;
            sbQuery.Append(" SELECT * ");
            sbQuery.Append(" FROM OCTR T0 ");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"" + CommonFields.ContractID + "\" = T1.\"" + CommonFields.ContractID + "\" ");
            sbQuery.Append(" Where  T0.\"" + CommonFields.ContractID + "\"='" + contractId + "' AND T1.U_Renewaldate >= CURRENT_DATE ");
            SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
            if (oRs.RecordCount == 0)
            {
                return false;
            }

            SAPbobsCOM.Documents oInvoice = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInvoices);
            oInvoice.CardCode = oRs.Fields.Item("CstmrCode").Value;
            string numtacard = "Contract #" + contractId;
            oInvoice.NumAtCard = numtacard;
            oInvoice.UserFields.Fields.Item("U_ContrNo").Value = contractId;
            int row = 0;
            while (!oRs.EoF)
            {
                if (row > 0)
                {
                    oInvoice.Lines.SetCurrentLine(row);
                }
                oInvoice.Lines.ItemCode = oRs.Fields.Item("U_ItemCode").Value;
                oInvoice.Lines.Quantity = 1;
                oInvoice.Lines.UnitPrice = oRs.Fields.Item("U_Price").Value;
                oRs.MoveNext();

                oInvoice.Lines.Add();
                row++;
            }
            oInvoice.Add();
            if (oCompany.GetLastErrorCode() != 0)
            {
                oApplication.StatusBar.SetText("Contract ID: " + contractId + " Exception: " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            else
            {
                oApplication.StatusBar.SetText("AR Invoice created against Contract ID: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
            return true;
        }

        public bool UpdateServiceContract(string contractId)
        {
            oApplication.StatusBar.SetText("Please wait updating contract id: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            //sbQuery.Length = 0;
            //sbQuery.Append(" SELECT * ");
            //sbQuery.Append(" FROM OCTR T0 ");
            //sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"" + CommonFields.ContractID + "\" = T1.\"" + CommonFields.ContractID + "\" ");
            //sbQuery.Append(" Where  T0.\"" + CommonFields.ContractID + "\"='" + contractId + "' ");
            //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
            //if (oRs.RecordCount == 0)
            //{
            //    return false;
            //}

            SAPbobsCOM.ServiceContracts oServiceContracts = (SAPbobsCOM.ServiceContracts)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oServiceContracts);
            oServiceContracts.GetByKey(Int32.Parse(contractId));
            int row = 0;
            string cardCode = oServiceContracts.CustomerCode;
            string priceList = objclsComman.SelectRecord("SELECT \"ListNum\" FROM OCRD WHERE \"CardCode\" ='" + cardCode + "' ");
            //while (!oRs.EoF)
            while (oServiceContracts.Lines.Count != row)
            {
                oServiceContracts.Lines.SetCurrentLine(row);
                int itemGroup = oServiceContracts.Lines.ItemGroup;
                string itemCode = oServiceContracts.Lines.UserFields.Fields.Item("U_ItemCode").Value;
                sbQuery.Length = 0;
                sbQuery.Append(" SELECT T0.\"Price\"  FROM ITM1 T0 ");
                sbQuery.Append(" INNER JOIN OPLN T1 ON T0.\"PriceList\" = T1.\"ListNum\" ");
                sbQuery.Append(" INNER JOIN OCRD  T2 ON T0.\"PriceList\" = T2.\"ListNum\" ");
                sbQuery.Append(" WHERE T0.\"ItemCode\" = '" + itemCode + "' AND T2.\"CardCode\" = '" + cardCode + "' ");
                string price = objclsComman.SelectRecord(sbQuery.ToString());
                double dblPrice = price == string.Empty ? 0 : double.Parse(price);

                sbQuery.Length = 0;
                sbQuery.Append(" SELECT T0.\"U_DiscPer\"  FROM ");
                sbQuery.Append(" \"@CRD_ITMGRP_DISC\" T0 ");
                sbQuery.Append(" WHERE T0.\"U_ItmGCod\" = '" + itemGroup + "' AND T0.\"U_CardCode\" = '" + cardCode + "' ");
                string discPer = objclsComman.SelectRecord(sbQuery.ToString());
                double dblDiscPer = discPer == string.Empty ? 0 : double.Parse(discPer);
                dblPrice = dblPrice - (dblPrice * dblDiscPer / 100);
                oServiceContracts.Lines.UserFields.Fields.Item("U_Price").Value = dblPrice;
                //oRs.MoveNext();
                row++;
            }
            oServiceContracts.Update();
            if (oCompany.GetLastErrorCode() != 0)
            {
                oApplication.StatusBar.SetText("Contract ID: " + contractId + " Exception: " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            else
            {
                oApplication.StatusBar.SetText("Contract ID: " + contractId + " has been updated successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
            return true;
        }

        #endregion
    }
}
