using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Microsoft.Win32.SafeHandles;
using System.IO;

namespace General
{
    class clsServiceContractList_Invoice : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string frDate = "frDate";
        const string toDate = "toDate";

        const string jbDocEntryUDF = "U_JBEn";
        const string productCodeUDF = "U_PrdCode";

        const string buttonExecute = "btExec";
        const string buttonFillData = "btFill";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Execute
                            if (pVal.ItemUID == buttonExecute)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsServiceContractEntity> list = new List<clsServiceContractEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Select", i) == "Y")
                                    {
                                        list.Add(new clsServiceContractEntity()
                                        {
                                            ContractId = oDT.GetValue("Contract No", i).ToString(),
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                for (int i = 0; i < list.Count; i++)
                                {
                                    AddInvoice(list[i].ContractId);
                                }
                                FillGrid();
                                //int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                //string itemCode = oForm.DataSources.UserDataSources.Item(CommonFields.ItemCode).Value.ToString();
                                //sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT \"U_TareWgt\",\"U_Gr_Wt\"");
                                //sbQuery.Append(" FROM " + CommonTables.ItemMasterData + " T0");
                                //sbQuery.Append(" WHERE \"" + CommonFields.ItemCode + "\" ='" + itemCode + "' ");

                                //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                //string tareWt = oRs.Fields.Item("U_TareWgt").Value.ToString();
                                //string grWt = oRs.Fields.Item("U_Gr_Wt").Value.ToString();

                            }
                            #endregion

                            #region Price Update
                            if (pVal.ItemUID == buttonFillData)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                FillGrid();
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal)
        {
            if (pVal.BeforeAction == false)
            {
                if (pVal.MenuUID == SAPCustomFormUIDEnum.SERCONTLIST_INVOICE.ToString())
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        #endregion

        #region Method

        public void LoadForm(string formMenuID)
        {
            //string rowNo, string jbDocEntry, string productCode,string qcType;
            objclsComman.LoadXML(formMenuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Add(frDate, SAPbouiCOM.BoDataType.dt_DATE, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(frDate).Specific;
            oEdit.DataBind.SetBound(true, "", frDate);

            oForm.DataSources.UserDataSources.Add(toDate, SAPbouiCOM.BoDataType.dt_DATE, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(toDate).Specific;
            oEdit.DataBind.SetBound(true, "", toDate);

            FillGrid();

            //oForm.DataSources.UserDataSources.Add(CommonFields.ItemCode, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.ItemCode).Specific;
            //oEdit.DataBind.SetBound(true, "", CommonFields.ItemCode);
            //oEdit.String = productCode;
            //FillGrid(jbDocEntry, productCode, qcType);
        }

        private void FillGrid()
        {
            oForm = oApplication.Forms.ActiveForm;
            //DateTime fromDate;
            //DateTime toDate;
            //objclsComman.GetQuarterFromAndToDate(DateTime.Now, out fromDate, out toDate);
            //string sapFromDate = objclsComman.ConvertDateToSAPDateFormat(fromDate);
            //string sapToDate = objclsComman.ConvertDateToSAPDateFormat(toDate);

            string sapFromDate = oForm.DataSources.UserDataSources.Item(frDate).ValueEx;
            string sapToDate = oForm.DataSources.UserDataSources.Item(toDate).ValueEx;
            sbQuery.Length = 0;

            sbQuery.Append(" SELECT 'Y' \"Select\", T0.\"ContractID\" AS \"Contract No\", T0.\"CstmrCode\" AS \"Business Partner Code\", T0.\"CstmrName\" AS \"Business Partner Name\", ");
            sbQuery.Append(" T0.\"CntrcType\"  AS \"Contract Type\",T0.\"Status\", T0.\"StartDate\", T0.\"EndDate\", T0.\"Descriptio\"   ");
            sbQuery.Append(" FROM OCTR T0");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"ContractID\"= T1.\"ContractID\"");
            sbQuery.Append(" WHERE ");
            //"T1.\"U_Renewaldate\" >= CURRENT_DATE AND ");
            sbQuery.Append(" (T1.\"U_Renewaldate\" >= '" + sapFromDate + "' AND T1.\"U_Renewaldate\" <= '" + sapToDate + "') AND ");
            sbQuery.Append(" (IFNULL(T1.\"TermDate\",'20990101') >= '" + sapToDate + "') AND ");
            sbQuery.Append(" NOT EXISTS ");
            sbQuery.Append(" ( SELECT 1 FROM OINV IT0 ");
            sbQuery.Append(" WHERE IT0.\"U_ContrNo\" = T0.\"ContractID\") ");
            sbQuery.Append(" GROUP BY ");
            sbQuery.Append(" T0.\"ContractID\" , T0.\"CstmrCode\", T0.\"CstmrName\", ");
            sbQuery.Append(" T0.\"CntrcType\"   ,T0.\"Status\", T0.\"StartDate\", T0.\"EndDate\", T0.\"Descriptio\"   ");


            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
            SAPbouiCOM.EditTextColumn oEditCol;
            oEditCol = ((SAPbouiCOM.EditTextColumn)(oGrid.Columns.Item(1)));
            oEditCol.LinkedObjectType = "190";
            oEditCol = ((SAPbouiCOM.EditTextColumn)(oGrid.Columns.Item(2)));
            oEditCol.LinkedObjectType = "2";


        }

        public bool AddInvoice(string contractId)
        {
            oApplication.StatusBar.SetText("Please wait creating invoice against contract id: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            //DateTime fromDate;
            //DateTime toDate;
            //objclsComman.GetQuarterFromAndToDate(DateTime.Now, out fromDate, out toDate);

            //string sapFromDate = objclsComman.ConvertDateToSAPDateFormat(fromDate);
            //string sapToDate = objclsComman.ConvertDateToSAPDateFormat(toDate);

            string sapFromDate = oForm.DataSources.UserDataSources.Item(frDate).ValueEx;
            string sapToDate = oForm.DataSources.UserDataSources.Item(toDate).ValueEx;
            string isFatherCardExists = "";
            sbQuery.Length = 0;

            sbQuery.Append(" SELECT \"FatherCard\" FROM OCRD T0 ");
            sbQuery.Append(" INNER JOIN OCTR T1 ON T0.\"" + CommonFields.CardCode + "\" =  T1.\"CstmrCode\" ");
            sbQuery.Append(" WHERE T1.\"" + CommonFields.ContractID + "\" = '" + contractId + "'  ");
            isFatherCardExists = objclsComman.SelectRecord(sbQuery.ToString());
            if (isFatherCardExists == string.Empty)
            {
                oApplication.StatusBar.SetText("Consolidated BP is not defined", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false; ;
            }

            sbQuery.Length = 0;
            sbQuery.Append(" SELECT T0.\"CstmrCode\",T1.\"U_ItemCode\",T1.\"U_Price\" ");
            sbQuery.Append(" FROM OCTR T0 ");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"" + CommonFields.ContractID + "\" = T1.\"" + CommonFields.ContractID + "\" ");
            sbQuery.Append(" Where  T0.\"" + CommonFields.ContractID + "\"='" + contractId + "' AND ");
            sbQuery.Append(" (T1.\"U_Renewaldate\" >= '" + sapFromDate + "' AND T1.\"U_Renewaldate\" <= '" + sapToDate + "') ");

            sbQuery.Append(" UNION ALL ");

            sbQuery.Append(" SELECT T0.\"CstmrCode\",T3.\"ItemCode\",T5.\"Price\" ");
            sbQuery.Append(" FROM OCTR T0 ");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"" + CommonFields.ContractID + "\" = T1.\"" + CommonFields.ContractID + "\" ");
            sbQuery.Append(" INNER JOIN OITB T2 ON T1.\"ItemGroup\" = T2.\"ItmsGrpCod\" ");
            sbQuery.Append(" INNER JOIN OITM T3 ON CONCAT('Local Presence ',SUBSTRING(T2.\"ItmsGrpNam\", LOCATE(T2.\"ItmsGrpNam\", '.'), LENGTH(T2.\"ItmsGrpNam\"))) = T3.\"" + CommonFields.ItemName + "\" ");
            sbQuery.Append(" INNER JOIN OCRD T4 ON T0.\"CstmrCode\" = T4.\"CardCode\" ");
            sbQuery.Append(" INNER JOIN ITM1 T5 ON T3.\"ItemCode\" = T5.\"ItemCode\" AND T4.\"ListNum\" = T5.\"PriceList\" ");
            sbQuery.Append(" Where  T0.\"" + CommonFields.ContractID + "\"='" + contractId + "' AND ");
            sbQuery.Append(" (T1.\"U_Renewaldate\" >= '" + sapFromDate + "' AND T1.\"U_Renewaldate\" <= '" + sapToDate + "') ");
            sbQuery.Append(" AND (T1.\"U_LocalPresence_P\" = '1' OR T1.\"U_LocalPresence_B\" = '1' ) ");

            sbQuery.Append(" UNION ALL ");

            sbQuery.Append(" SELECT T0.\"CstmrCode\",T3.\"ItemCode\",T5.\"Price\" ");
            sbQuery.Append(" FROM OCTR T0 ");
            sbQuery.Append(" INNER JOIN CTR1 T1 ON T0.\"" + CommonFields.ContractID + "\" = T1.\"" + CommonFields.ContractID + "\" ");
            sbQuery.Append(" INNER JOIN OITB T2 ON T1.\"ItemGroup\" = T2.\"ItmsGrpCod\" ");
            sbQuery.Append(" INNER JOIN OITM T3 ON CONCAT('WHOIS ',SUBSTRING(T2.\"ItmsGrpNam\", LOCATE(T2.\"ItmsGrpNam\", '.'), LENGTH(T2.\"ItmsGrpNam\"))) = T3.\"" + CommonFields.ItemName + "\" ");
            sbQuery.Append(" INNER JOIN OCRD T4 ON T0.\"CstmrCode\" = T4.\"CardCode\" ");
            sbQuery.Append(" INNER JOIN ITM1 T5 ON T3.\"ItemCode\" = T5.\"ItemCode\" AND T4.\"ListNum\" = T5.\"PriceList\" ");
            sbQuery.Append(" Where  T0.\"" + CommonFields.ContractID + "\"='" + contractId + "' AND ");
            sbQuery.Append(" (T1.\"U_Renewaldate\" >= '" + sapFromDate + "' AND T1.\"U_Renewaldate\" <= '" + sapToDate + "') ");
            sbQuery.Append(" AND (T1.\"U_WHOISprivacy_P\" = '1' OR T1.\"U_WHOISprivacy_B\" = '1' ) ");

            SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
            if (oRs.RecordCount == 0)
            {
                return false;
            }

            SAPbobsCOM.Documents oInvoice = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInvoices);
            oInvoice.CardCode = oRs.Fields.Item("CstmrCode").Value;
            string numtacard = "Contract #" + contractId;
            oInvoice.NumAtCard = numtacard;
            oInvoice.UserFields.Fields.Item("U_ContrNo").Value = contractId;
            int row = 0;
            while (!oRs.EoF)
            {
                if (row > 0)
                {
                    oInvoice.Lines.SetCurrentLine(row);
                }
                oInvoice.Lines.ItemCode = oRs.Fields.Item("U_ItemCode").Value;
                oInvoice.Lines.Quantity = 1;
                oInvoice.Lines.UnitPrice = oRs.Fields.Item("U_Price").Value;
                oRs.MoveNext();

                oInvoice.Lines.Add();
                row++;
            }
            oInvoice.Add();
            if (oCompany.GetLastErrorCode() != 0)
            {
                oApplication.StatusBar.SetText("Contract ID: " + contractId + " Exception: " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            else
            {
                oApplication.StatusBar.SetText("AR Invoice created against Contract ID: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                UpdateServiceContract(contractId);
            }
            return true;
        }

        public bool UpdateServiceContract(string contractId)
        {
            oApplication.StatusBar.SetText("Please wait updating contract id: " + contractId, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

            SAPbobsCOM.ServiceContracts oServiceContracts = (SAPbobsCOM.ServiceContracts)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oServiceContracts);
            oServiceContracts.GetByKey(Int32.Parse(contractId));
            int row = 0;

            //objclsComman.GetQuarterFromAndToDate(DateTime.Now, out fromDate, out toDate);
            string sapFromDate = oForm.DataSources.UserDataSources.Item(frDate).ValueEx;
            string sapToDate = oForm.DataSources.UserDataSources.Item(toDate).ValueEx;

            DateTime dtSAPFromDate = objclsComman.ConvertSAPDateToDateTime(sapFromDate);
            DateTime dtSAPToDate = objclsComman.ConvertSAPDateToDateTime(sapToDate);

            while (oServiceContracts.Lines.Count != row)
            {
                oServiceContracts.Lines.SetCurrentLine(row);

                DateTime renDate = oServiceContracts.Lines.UserFields.Fields.Item("U_Renewaldate").Value;

                if (renDate >= dtSAPFromDate && renDate <= dtSAPToDate)
                {
                    oServiceContracts.Lines.UserFields.Fields.Item("U_Renewaldate").Value = renDate.AddYears(1);
                }
                row++;
            }
            oServiceContracts.Update();
            if (oCompany.GetLastErrorCode() != 0)
            {
                oApplication.StatusBar.SetText("Contract ID: " + contractId + " Exception: " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            else
            {
                oApplication.StatusBar.SetText("Contract ID: " + contractId + " has been updated successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
            return true;
        }

        #endregion
    }
}
