﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyTransfer
{
    public partial class frmBusinessPartner : Form
    {
        clsDataAccess objclsDataAccess = new clsDataAccess();
        public bool isopen = false;

        public frmBusinessPartner()
        {
            InitializeComponent();
        }

        private void BusinessPartner_Load(object sender, EventArgs e)
        {
            isopen = true;
            Addon.SAPLogin();
        }

    }
}
