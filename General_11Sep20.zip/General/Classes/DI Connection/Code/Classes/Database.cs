﻿using System;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using SAPbobsCOM;

namespace CompanyTransfer
{
    internal class Database
    {
        /// <summary>
        /// Prepare current SAP Database by creating required user defined objects 
        /// if they are not already defined
        /// </summary>
        public void PrepareDatabase()
        {
            string tables, fields, udos;
            GetDatabaseResources(out tables, out fields, out udos);

            CreateTables(tables);
            CreateFields(fields);
            CreateUDOs(udos);
        }

        /// <summary>
        /// Get XML files for table, field and UDO definitions
        /// </summary>
        /// <returns></returns>
        private void GetDatabaseResources(out string tables, out string fields, out string UDOs)
        {
            var assembly = Assembly.GetEntryAssembly();

            tables = File.ReadAllText(ConfigurationManager.AppSettings["tableResource"]);
            fields = File.ReadAllText(ConfigurationManager.AppSettings["fieldResource"]);
            UDOs = File.ReadAllText(ConfigurationManager.AppSettings["objectResource"]);
        }

        /// <summary>
        /// Create SAP Tables
        /// </summary>
        /// <param name="xml">XML as String contining definition for SAP Custom Tables</param>
        private void CreateTables(string xml)
        {
            Addon.Company.XmlExportType = BoXmlExportTypes.xet_ExportImportMode;
            Addon.Company.XMLAsString = true;

            var iElementCount = Addon.Company.GetXMLelementCount(xml);

            for (var iCounter = 0; iCounter < iElementCount; iCounter++)
            {
                var objUserTables = (UserTablesMD)Addon.Company.GetBusinessObject(BoObjectTypes.oUserTables);
                objUserTables = (UserTablesMD)Addon.Company.GetBusinessObjectFromXML(xml, iCounter);

                if (!TableExists(objUserTables.TableName))
                {
                    //Addon.B1App.StatusBar.SetText($"Creating table {objUserTables.TableName}", BoMessageTime.bmt_Medium,
                    //    BoStatusBarMessageType.smt_Warning);

                    var errCode = objUserTables.Add();
                    if (errCode != 0)
                    {

                    }
                }

                Marshal.ReleaseComObject(objUserTables);
                GC.Collect();
            }
        }

        /// <summary>
        /// Create SAP Fields
        /// </summary>
        /// <param name="xml">XML as String containing definition for SAP Custom Fields</param>
        private void CreateFields(string xml)
        {
            Addon.Company.XmlExportType = BoXmlExportTypes.xet_ExportImportMode;
            Addon.Company.XMLAsString = true;

            int errCode;

            var iElementCount = Addon.Company.GetXMLelementCount(xml);

            for (var iCounter = 0; iCounter < iElementCount; iCounter++)
            {
                var objUserFields = (UserFieldsMD)Addon.Company.GetBusinessObject(BoObjectTypes.oUserFields);
                objUserFields = (UserFieldsMD)Addon.Company.GetBusinessObjectFromXML(xml, iCounter);

                if (!FieldExists(objUserFields.TableName, objUserFields.Name))
                {
                    //Addon.B1App.StatusBar.SetText($"Creating field {objUserFields.TableName}.{objUserFields.Name}",
                    //    BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Warning);

                    errCode = objUserFields.Add();

                    if (errCode != 0)
                    {
                        string errDesc = Addon.Company.GetLastErrorDescription();
                        //Addon.B1App.MessageBox(
                        //    $"Could not create field {objUserFields.TableName}.{objUserFields.Name} - {Addon.Company.GetLastErrorDescription()}");
                    }
                }

                Marshal.ReleaseComObject(objUserFields);
                GC.Collect();
            }
            ;
        }

        /// <summary>
        /// Create User Defined Objects (UDOs)
        /// </summary>
        /// <param name="xml">XML as String containing definition for SAP UDOs</param>
        private void CreateUDOs(string xml)
        {
            Addon.Company.XmlExportType = BoXmlExportTypes.xet_ExportImportMode;
            Addon.Company.XMLAsString = true;

            int errCode;

            var iElementCount = Addon.Company.GetXMLelementCount(xml);

            for (var iCounter = 0; iCounter < iElementCount; iCounter++)
            {
                var oUDO = (UserObjectsMD)Addon.Company.GetBusinessObjectFromXML(xml, Convert.ToInt32(iCounter));

                if (!ObjectExists(oUDO.Code))
                {
                    //Addon.B1App.StatusBar.SetText($"Creating User defined object {oUDO.Name}", BoMessageTime.bmt_Medium,
                    //    BoStatusBarMessageType.smt_Warning);

                    errCode = oUDO.Add();

                    if (errCode != 0)
                    {
                        //Addon.B1App.MessageBox(
                        //    $"Could not create USer defined object {oUDO.Name} - {Addon.Company.GetLastErrorDescription()}");
                    }
                }

                Marshal.ReleaseComObject(oUDO);
            }
            ;
        }

        /// <summary>
        /// Check if Table already exists in current SAP database
        /// </summary>
        /// <param name="tableName">Name of table we are checking</param>
        /// <returns></returns>
        private bool TableExists(string tableName)
        {
            var oRs = (Recordset)Addon.Company.GetBusinessObject(BoObjectTypes.BoRecordset);
            oRs.DoQuery(string.Format("SELECT 'TRUE' FROM OUTB WHERE TableName = '{0}'", tableName));

            var retVal = oRs.RecordCount > 0;

            Marshal.ReleaseComObject(oRs);
            GC.Collect();

            return retVal;
        }

        /// <summary>
        /// Check if Custom Field already exists in current SAP database
        /// </summary>
        /// <param name="tableName">Name of table we are checking</param>
        /// <param name="fieldName">Name of field we are checking</param>
        /// <returns></returns>
        private bool FieldExists(string tableName, string fieldName)
        {
            var oRs = (Recordset)Addon.Company.GetBusinessObject(BoObjectTypes.BoRecordset);
            oRs.DoQuery(string.Format("SELECT 'TRUE' FROM CUFD WHERE TableId = '{0}' AND AliasID = '{1}'", tableName,
                fieldName));

            var retVal = oRs.RecordCount > 0;

            Marshal.ReleaseComObject(oRs);
            GC.Collect();

            return retVal;
        }

        /// <summary>
        /// Check if UDO alerady exists in SAP
        /// </summary>
        /// <param name="UDOId">UDO id we are checking</param>
        /// <returns></returns>
        private bool ObjectExists(string UDOId)
        {
            var oRs = (Recordset)Addon.Company.GetBusinessObject(BoObjectTypes.BoRecordset);
            oRs.DoQuery(string.Format("SELECT 'TRUE' FROM OUDO WHERE Code = '{0}'", UDOId));

            var retVal = oRs.RecordCount > 0;

            Marshal.ReleaseComObject(oRs);
            GC.Collect();

            return retVal;
        }
    }
}