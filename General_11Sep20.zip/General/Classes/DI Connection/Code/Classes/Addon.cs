﻿using System;
using System.Data.SqlClient;
using Company = SAPbobsCOM.Company;

namespace CompanyTransfer
{
    /// <summary>
    ///     Add-On framework main class defines method to initialize the framework
    /// </summary>
    public static class Addon
    {
        #region Add-On framework Properties

        public static Company Company;

        #endregion

        public static void Init()
        {
            if (Addon.Company == null)
            {
                SAPLogin();
            }
            PrepareDatabase();
        }

        public static string SAPLogin()
        {
            string SQLConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["sapConnectionString"].ToString();
            Company = new SAPbobsCOM.Company();

            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(SQLConnectionString);
               // Company.LicenseServer = System.Configuration.ConfigurationManager.AppSettings["LicenseServer"].ToString() + ":30015";
                Company.Server = builder.DataSource;
                Company.CompanyDB = builder.InitialCatalog;
                Company.DbUserName = builder.UserID;
                Company.DbPassword = builder.Password;
                Company.UserName = System.Configuration.ConfigurationManager.AppSettings["SAPUserCode"].ToString();
                Company.Password = System.Configuration.ConfigurationManager.AppSettings["SAPPassword"].ToString();
                Company.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_HANADB;
                int i = Company.Connect();
                if (i == 0)
                {
                    return i.ToString();
                }
                else
                {
                    string ErrorMessage = Company.GetLastErrorCode() + " : " + Company.GetLastErrorDescription();
                    return ErrorMessage;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private static void PrepareDatabase()
        {
            var database = new Database();
            database.PrepareDatabase();
        }
    }
}