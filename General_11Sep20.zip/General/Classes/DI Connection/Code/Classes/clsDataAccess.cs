﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyTransfer
{
    public class clsDataAccess
    {
        #region Variables
        private string SQLConnectionString;
        private SqlConnection conn;
        #endregion

        #region Constructor

        public clsDataAccess()
        {
            SQLConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SAPConnectionString"].ToString();
        }

        #endregion

        #region Database Method

        public SqlConnection OpenConnection()
        {
            try
            {
                SQLConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SAPConnectionString"].ToString();
                conn = new SqlConnection();
                conn.ConnectionString = SQLConnectionString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return conn;
        }

        private void CloseConnection(SqlConnection conn)
        {
            conn.Close();
        }

        public void Fill_Combo_Value_Display(ComboBox cmb, string Query, string Value, string Display)
        {
            try
            {
                cmb.Items.Clear();
                DataSet ds = new DataSet();
                ds.Clear();
                SqlDataAdapter adp = new SqlDataAdapter(Query, OpenConnection());
                adp.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row[Display] = "Select";
                ds.Tables[0].Rows.InsertAt(row, 0);
                CloseConnection(OpenConnection());
                cmb.DataSource = ds.Tables[0];
                cmb.DisplayMember = Display;
                cmb.ValueMember = Value;
                cmb.Text = "Select";
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        public List<T> ConvertTo<T>(DataTable datatable) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames));
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public T getObject<T>(DataRow row, List<string> columnsName) where T : new()
        {
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                foreach (PropertyInfo objProperty in Properties)
                {
                    columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                    if (!string.IsNullOrEmpty(columnname))
                    {
                        value = row[columnname].ToString();
                        if (!string.IsNullOrEmpty(value))
                        {
                            if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                            {
                                value = row[columnname].ToString().Replace("$", "").Replace(",", "");
                                objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                            }
                            else
                            {
                                value = row[columnname].ToString();
                                objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                            }
                        }
                    }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }

        private T BindData_ToClass<T>(DataTable dt)
        {
            DataRow dr = dt.Rows[0];

            // Get all columns' name
            List<string> columns = new List<string>();
            foreach (DataColumn dc in dt.Columns)
            {
                columns.Add(dc.ColumnName);
            }

            // Create object
            var ob = Activator.CreateInstance<T>();

            // Get all fields
            var fields = typeof(T).GetFields();
            foreach (var fieldInfo in fields)
            {
                if (columns.Contains(fieldInfo.Name))
                {
                    // Fill the data into the field
                    fieldInfo.SetValue(ob, dr[fieldInfo.Name]);
                }
            }

            // Get all properties
            var properties = typeof(T).GetProperties();
            foreach (var propertyInfo in properties)
            {
                if (columns.Contains(propertyInfo.Name))
                {
                    // Fill the data into the property
                    propertyInfo.SetValue(ob, dr[propertyInfo.Name]);
                }
            }

            return ob;
        }

        public DataSet FillDataset(string Query, SqlConnection conn)
        {
            DataSet ods = new DataSet();
            SqlCommand cmd = null;
            SqlDataAdapter da = null;

            try
            {
                cmd = new SqlCommand(Query, conn);
                da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch
            {
                //MessageBox.Show(ex.Message);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Close();
                }
                if (ods != null)
                {
                    ods.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (da != null)
                {
                    da.Dispose();
                }
            }
            return ods;

        }

        public string GetRecord(string Query, SqlConnection conn)
        {
            string Value = "";
            SqlDataReader dr = null;
            SqlCommand cmd = null;
            try
            {
                conn.Open();
                cmd = new SqlCommand(Query, conn);

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    Value = dr[0].ToString();
                }
                return Value;
            }

            finally
            {
                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Close();
                }
                if (dr != null)
                {
                    dr.Close();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
            }
        }

        public DataSet FillDataset_Params(string commandText, SqlConnection conn, out string message, params SqlParameter[] parameters)
        {
            message = string.Empty;
            DataSet ods = new DataSet();
            SqlDataAdapter da = null;
            SqlCommand cmd = null;
            try
            {

                cmd = new SqlCommand();
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = commandText;
                cmd.Connection = conn;
                da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Close();
                }
                if (ods != null)
                {
                    ods.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (da != null)
                {
                    da.Dispose();
                }
            }
            return ods;

        }

        #region Commented

        /* Stored Proceudre With SQL Parameters Example
         * http://www.c-sharpcorner.com/forums/generic-method-to-add-sql-parameters-dynamically-for-executing-sql-parameterized-query-for-adonet
         DataSet FetchData(SqlConnection connection, string queryText, params SqlParameter[] parameters)
           {
              // ...    
              command.Parameters.Clear(); // if needed 
              command.Parameters.AddRange(parameters);
              // ... 
           }

        and then call it, for example, with something like this:

          SqlParameter param1 = new SqlParameter("Name", SqlDbType.VarChar);
          param1.Value = "Mahesh";
          SqlParameter param2 = new SqlParameter("Id", SqlDbType.Int);
          param1.Value = 1;

          DataSet ds = FetchData(conn, queryText, param1, param2);
         */

        #endregion

        #endregion



        #region Get Database Name

        public string GetDBName()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(SQLConnectionString);
            return builder.InitialCatalog;
        }

        #endregion

        #region AES Cryptography

        public static string DecryptStringAES(string cipherText)
        {

            var keybytes = Encoding.UTF8.GetBytes("7061737323313233");
            var iv = Encoding.UTF8.GetBytes("7061737323313233");
            cipherText = cipherText.Replace(" ", "+");
            var encrypted = Convert.FromBase64String(cipherText);
            var decriptedFromJavascript = DecryptStringFromBytes(encrypted, keybytes, iv);
            return string.Format(decriptedFromJavascript);
        }

        private static string DecryptStringFromBytes(byte[] cipherText, byte[] key, byte[] iv)
        {
            // Check arguments.
            if (cipherText == null || cipherText.Length <= 0)
            {
                throw new ArgumentNullException("cipherText");
            }
            if (key == null || key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            if (iv == null || iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }

            // Declare the string used to hold
            // the decrypted text.
            string plaintext = null;

            // Create an RijndaelManaged object
            // with the specified key and IV.
            using (var rijAlg = new System.Security.Cryptography.RijndaelManaged())
            {
                //Settings
                rijAlg.Mode = System.Security.Cryptography.CipherMode.CBC;
                rijAlg.Padding = System.Security.Cryptography.PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = key;
                rijAlg.IV = iv;

                // Create a decrytor to perform the stream transform.
                var decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);
                try
                {
                    // Create the streams used for decryption.
                    using (var msDecrypt = new System.IO.MemoryStream(cipherText))
                    {
                        using (var csDecrypt = new System.Security.Cryptography.CryptoStream(msDecrypt, decryptor, System.Security.Cryptography.CryptoStreamMode.Read))
                        {

                            using (var srDecrypt = new System.IO.StreamReader(csDecrypt))
                            {
                                // Read the decrypted bytes from the decrypting stream
                                // and place them in a string.
                                plaintext = srDecrypt.ReadToEnd();

                            }

                        }
                    }
                }
                catch
                {
                    plaintext = "keyError";
                }
            }

            return plaintext;
        }

        private byte[] EncryptStringToBytes(string plainText, byte[] key, byte[] iv)
        {
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
            {
                throw new ArgumentNullException("plainText");
            }
            if (key == null || key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            if (iv == null || iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            byte[] encrypted;
            // Create a RijndaelManaged object
            // with the specified key and IV.
            using (var rijAlg = new System.Security.Cryptography.RijndaelManaged())
            {
                rijAlg.Mode = System.Security.Cryptography.CipherMode.CBC;
                rijAlg.Padding = System.Security.Cryptography.PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = key;
                rijAlg.IV = iv;

                // Create a decrytor to perform the stream transform.
                var encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (var msEncrypt = new System.IO.MemoryStream())
                {
                    using (var csEncrypt = new System.Security.Cryptography.CryptoStream(msEncrypt, encryptor, System.Security.Cryptography.CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new System.IO.StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            // Return the encrypted bytes from the memory stream.
            return encrypted;
        }

        #endregion

        public static DateTime ConvertToDateTime_FromAngularDatetime(string Value)
        {
            DateTime dtValue;
            dtValue = DateTime.MinValue;
            try
            {
                string StartDate = string.Empty;
                StartDate = Value;
                if (StartDate.Contains("T"))
                {
                    StartDate = Value.Replace(Value.Substring(Value.LastIndexOf('T')), "");
                    dtValue = DateTime.ParseExact(StartDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                }
                else if (StartDate.Contains(","))
                {
                    StartDate = Value.Replace(Value.Substring(Value.LastIndexOf(',')), "");
                    dtValue = DateTime.ParseExact(StartDate, "MM/MM/dd", CultureInfo.InvariantCulture);
                }
                else
                {
                    dtValue = DateTime.ParseExact(StartDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
            }
            return dtValue;
        }

    }
}
