		sap.ui.define([
			"sap/ui/core/mvc/Controller",
			"TMR/TMR/codeModule/messages",
			"TMR/TMR/codeModule/serviceLayerQuery"
		], function (Controller, message, Query) {
			"use strict";

			return Controller.extend("TMR.TMR.controller.View1", {
				onInit: function () {
					
					// var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
					// sap.ui.getCore().setModel(userModel, "userapi");
					var today = new Date();
					var dd = today.getDate();
					var mm = today.getMonth() + 1;
					var yyyy = today.getFullYear();
					var hour = today.getHours();
					var Minutes = today.getMinutes();
					var Seconds = today.getSeconds();
					var today1 = (dd + '.' + mm + '.' + yyyy + ' ' + hour + ':' + Minutes + ':' + Seconds);

					this.getView().byId("date").setText(today1.valueOf(Text));
					Query.setConnection();
					var oSelect = this.getView().byId("idTypeCombo");
					var newItem = new sap.ui.core.Item({
						key: "E",
						text: "Employee"
					});
					oSelect.addItem(newItem);
					newItem = new sap.ui.core.Item({
						key: "M",
						text: "Machine"
					});
					oSelect.addItem(newItem);
					newItem = new sap.ui.core.Item({
						key: "R",
						text: "Routing States"
					});
					oSelect.addItem(newItem);
				},
				onCreateUDF: function (oEvent) {
					//-Fields of table OTMR
					Query._createUDFs("ProdOrder", "N", 6, "Production order", null, null, null, "@OTMRT", 0, 6, "N", null);
					Query._createUDFs("Resource", "A", 50, "Resource Code", null, null, null, "@OTMRT", 2, 50, "N", null);
					Query._createUDFs("Routes", "A", 50, "Routing Code", null, null, null, "@OTMRT", 1, 50, "N", null);
					Query._createUDFs("LineNum", "N", 6, "Line number", null, null, null, "@OTMRT", 3, 6, "N", null);

					//-Fields of Table TMR1
					Query._createUDFs("ProdOrder", "N", 6, "Production order", null, "OTMRT", null, "@TMR1T", 0, 6, "N", null);
					Query._createUDFs("LineNum", "N", 6, "Line number", null, null, null, "@TMR1T", 1, 6, "N", null);
					Query._createUDFs("LineCount", "N", 6, "Line count", null, null, null, "@TMR1T", 2, 6, "N", null);
					Query._createUDFs("User", "A", 50, "User name", null, null, null, "@TMR1T", 3, 50, "N", null);
					Query._createUDFs("cStatus", "A", 2, "Cusrrent status", null, null, "NS", "@TMR1T", 4, 2, "N", [{
						"Value": "NS",
						"Description": "Not started"
					}, {
						"Value": "IP",
						"Description": "In process"
					}, {
						"Value": "ST",
						"Description": "Stopped"
					}, {
						"Value": "CP",
						"Description": "Completed"
					}, {
						"Value": "CN",
						"Description": "Cancel"
					}]);
					Query._createUDFs("Start_Date", "D", 8, "Start date", null, null, null, "@TMR1T", 5, 8, "N", null);
					Query._createUDFs("Start_Time", "N", 6, "Start time", "T", null, null, "@TMR1T", 6, 6, "N", null);
					Query._createUDFs("Stop_Date", "D", 8, "Stop date", null, null, null, "@TMR1T", 7, 8, "N", null);
					Query._createUDFs("Stop_Time", "N", 6, "Stop time", "T", null, null, "@TMR1T", 8, 6, "N", null);

				},

				onCreateUDT: function (oEvent) {
					Query._createUDTs("OTMRT", "TMR Usage", 5, "N");
					Query._createUDTs("TMR1T", "TMR User Activity", 5, "N");
				},
				onCreateUDO: function (oEvent) {
					Query._createUDO();
				},
				onPressGo: function (oEvent) {

					// var url = "https://webidecp-p2002344358trial.dispatcher.hanatrial.ondemand.com/services/userapi/currentUser";
					// var oDataUser = Query._getOdata(url);

					// usermodel.loaddata("/services/userapi/currentuser",null, false);
					// this.setmodel(usermodel, "userapi");
					// var usermodel = new sap.ui.model.json.JSONModel();
					// usermodel.loadData("/services/userapi/currentuser", null, false, null, null, null, null);
					//var userInfo = new sap.ushell.Container.getService("UserInfo").getId();
					var type = this.getView().byId("idTypeCombo").getSelectedKey();
					if (type === "") {
						message.error("Please select Type");
						return;
					}

					var id = this.getView().byId("idValues").getSelectedKey();
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					//oRouter.navTo("View2");
					oRouter.navTo("prodOrder", {
						Type: type,
						ID: id
					});
				},
				// onPressValues: function (url) {
				// 	var type = this.getView().byId("idTypeCombo").getValue();
				// 	if (type == "") {
				// 		message.error("Please select Type");
				// 		//return;
				// 	}
				// 	var serviceLayerURL = url;
				// 	var that = this;
				// 	$.ajax({
				// 		url: serviceLayerURL,
				// 		xhrFields: {
				// 			withCredentials: true
				// 		},
				// 		// data: jData,
				// 		type: "GET",
				// 		dataType: "json",
				// 		async: false,
				// 		success: function (oData, oResponse) {
				// 			var oComboValue = that.byId("idValues");
				// 			$.each(oData.value, function (i, value) {
				// 				var oItem = new sap.ui.core.ListItem();
				// 				oItem.setText(value.Description);
				// 				oItem.setKey(value.Code);
				// 				oComboValue.addItem(oItem);
				// 			});
				// 		},
				// 		error: function (oError) {
				// 			message.error("Error: " + oError.responseJSON.error.message.value);
				// 		}
				// 	});
				// },
				onChangeType: function (oEvent) {
						var type = this.getView().byId("idTypeCombo").getSelectedKey();
						var oComboValue = this.getView().byId("idValues");
						oComboValue.removeAllItems();
						var oDataIn;
						if (type === null) {
							message.error("Please select Type");
							return;
						}
						var url = "https://b4hsl.acomi.dk/b1s/v1/";
						if (type === "E") {
							url = url + "EmployeesInfo?$select=EmployeeID,FirstName";
							oDataIn = Query._getOdata(url);
							//var oModel = new sap.ui.model.json.JSONModel(oDataIn);
							//oComboValue.setModel(oModel);
							$.each(oDataIn.value, function (i, value) {
								var oItem = new sap.ui.core.ListItem();
								oItem.setAdditionalText(value.FirstName);
								oItem.setText(value.EmployeeID);
								oItem.setKey(value.EmployeeID);
								oComboValue.addItem(oItem);
							});
						} else if (type === "M") {
							url = url + "Resources?$select=Code,Name&$filter=(Type eq  'rtMachine')";
							oDataIn = Query._getOdata(url);
							$.each(oDataIn.value, function (i, value) {
								var oItem = new sap.ui.core.ListItem();
								oItem.setAdditionalText(value.Name);
								oItem.setText(value.Code);
								oItem.setKey(value.Code);
								oComboValue.addItem(oItem);
							});
						} else if (type === "R") {
							url = url + "RouteStages?$select=Code,Description";
							oDataIn = Query._getOdata(url);
							$.each(oDataIn.value, function (i, value) {
								var oItem = new sap.ui.core.ListItem();
								oItem.setAdditionalText(value.Code);
								oItem.setText(value.Description);
								oItem.setKey(value.Description);
								oComboValue.addItem(oItem);
							});
						}
					}
					/**
					 *@memberOf TMR.TMR.controller.View1
					 */
					// action: function (oEvent) {
					// 	var that = this;
					// 	var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
					// 	var eventType = oEvent.getId();
					// 	var aTargets = actionParameters[eventType].targets || [];
					// 	aTargets.forEach(function (oTarget) {
					// 		var oControl = that.byId(oTarget.id);
					// 		if (oControl) {
					// 			var oParams = {};
					// 			for (var prop in oTarget.parameters) {
					// 				oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
					// 			}
					// 			oControl[oTarget.action](oParams);
					// 		}
					// 	});
					// 	var oNavigation = actionParameters[eventType].navigation;
					// 	if (oNavigation) {
					// 		var oParams = {};
					// 		(oNavigation.keys || []).forEach(function (prop) {
					// 			oParams[prop.name] = encodeURIComponent(JSON.stringify({
					// 				value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
					// 				type: prop.type
					// 			}));
					// 		});
					// 		if (Object.getOwnPropertyNames(oParams).length !== 0) {
					// 			this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
					// 		} else {
					// 			this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
					// 		}
					// 	}
					// }
			});
		});