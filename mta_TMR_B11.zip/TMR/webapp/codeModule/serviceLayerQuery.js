sap.ui.define([
	"TMR/TMR/codeModule/messages"
], function (message) {
	return {
		_createUDFs: function (name, type, size, description, subType, linkedTable, defaultValue, tableName, fieldID, editSize, mandatory, validValuesMD) 
		{
			var oData = JSON.stringify({
				"Name": name,
				"Type": type,
				"Size": size,
				"Description": description,
				"SubType": subType,
				"LinkedTable": linkedTable,
				"DefaultValue": defaultValue,
				"TableName": tableName,
				"FieldID": fieldID,
				"EditSize": editSize,
				"Mandatory": mandatory,
				"ValidValuesMD": validValuesMD
			});
			var udfCreateURL = "https://b4hsl.acomi.dk/b1s/v1/UserFieldsMD";
			this._postData(udfCreateURL, oData);
		},
		_createUDTs: function (name, description, tableType, archivable) {
			var oData = JSON.stringify({
				"TableName": name,
				"TableDescription": description,
				"TableType": tableType,
				"Archivable": archivable
				//	"ArchiveDateField": null
			});
			var udtCreateURL = "https://b4hsl.acomi.dk/b1s/v1/UserTablesMD";
			this._postData(udtCreateURL, oData);
		},
		_createUDO: function () {
			var oData = JSON.stringify({
			"TableName" : "OTMRT",
         "Code" : "UDOTMR",
         "LogTableName" : "AOTMRT",
         "CanCreateDefaultForm" : "tNO",
         "ObjectType" : "boud_Document",
         "ExtensionName" : null,
         "CanCancel" : "tYES",
         "CanDelete" : "tYES",
         "CanLog" : "tYES",
         "ManageSeries" : "tYES",
         "CanFind" : "tNO",
         "CanYearTransfer" : "tNO",
         "Name" : "TMR Posting",
         "CanClose" : "tYES",
         "OverwriteDllfile" : "tYES",
         "UseUniqueFormType" : "tYES",
         "CanArchive" : "tNO",
         "MenuItem" : "tNO",
         "MenuCaption" : "",
         "FatherMenuID" : null,
         "Position" : null,
         "MenuUID" : null,
         "EnableEnhancedForm" : "tYES",
         "RebuildEnhancedForm" : "tYES",
         "FormSRF" : null,
         "UserObjectMD_ChildTables" : [
            {
               "SonNumber" : 1,
               "TableName" : "TMR1T",
               "LogTableName" : "ATMR1T",
               "Code" : "UDOTMR",
               "ObjectName" : "TMR1T"
            }
         ],
         "UserObjectMD_FindColumns" : [],
         "UserObjectMD_FormColumns" : [],
         "UserObjectMD_EnhancedFormColumns" : []
			});
			var udtCreateURL = "https://b4hsl.acomi.dk/b1s/v1/UserObjectsMD";
			this._postData(udtCreateURL, oData);
		},
		setConnection: function () {
			var user = "acomi\\pkj";
			var pass = "VVpipapspk1!";
			var comp = "PKJ_20200604";
			var jData = JSON.stringify({
				CompanyDB: comp,
				UserName: user,
				Password: pass
			});
			var serviceLayerLoginURL = "https://b4hs2.acomi.local:50000/b1s/v1/Login";
			//	var that = this;
			$.ajax({
				url: serviceLayerLoginURL,
				xhrFields: {
					withCredentials: true
				},
				// headers: {
    //                 "Content-Type": "text/javascript",
				// 	"Access-Control-Allow-Origin": "*"
				// },
				data: jData,
				dataType: "json",
				type: "POST",
				//async: true,
				crossDomain: true,
				success: function (result, xhr) {
					message.success("Connected with SAP system");
					//	that._createUDFs();
				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
		},
		_getOdata: function (urlIn) {
			var oDataOut;
			$.ajax({
				url: urlIn,
				xhrFields: {
					withCredentials: true
				},
				type: "GET",
				dataType: "json",
				async: false,
				success: function (oData, oResponse) {
					oDataOut = oData;
				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
			return oDataOut;
		},
		_patchData: function (url, jData, status, docEntry) {
			$.ajax({
				url: url,
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				dataType: "json",
				async: false,
				//	"B1S-ReplaceCollectionsOnPatch": true,
				type: "PATCH",
				success: function (result, xhr) {

					if (status === 1) {
						message.success("Order: " + docEntry + " is stopped now.");
					} else {
						message.success("Order: " + docEntry + " is started now.");
					}

				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
		},
		_postData: function (url, jData) {
			$.ajax({
				url: url,
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				async: false,
				dataType: "json",
				type: "POST",
				success: function (result, xhr) {
					message.success("Success: Data posted in SAP");
				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
		},
		_goodsIssue: function (jData) {
			var giPostURL = "https://b4hsl.acomi.dk/b1s/v1/InventoryGenExits";
			this._postData(giPostURL, jData);
		},
		_goodsReceipt: function (jData) {
			var grPostURL = "https://b4hsl.acomi.dk/b1s/v1/InventoryGenEntries";
			this._postData(grPostURL, jData);
		}

	};
});