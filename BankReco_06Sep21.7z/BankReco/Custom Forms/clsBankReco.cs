﻿using BankRecoAddon.Classes;
using BankRecoAddon.Extensions;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BankRecoAddon.Custom_Forms
{
    class clsBankReco : Connection
    {
        #region
        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "@BANKRECO";
        const string rowTable = "@BANKRECO1";
        const string menuID = "BANKRECO";
        const string matrixUID = "mtx1";


        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btLoad")
                            {
                                string accountcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BankGL", 0).Trim();
                                if (accountcode != string.Empty)
                                {
                                    LoadData(accountcode);
                                }
                            }
                            else if (pVal.ItemUID == "btSDraft")
                            {
                                int i = oApplication.MessageBox("Do you really want to proceed?", 1, "Yes", "No");
                                if (i == 1)
                                {
                                    if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                    {
                                        oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                    }
                                    oForm.Items.Item("1").Visible = true;
                                    oForm.Items.Item("1").Click(BoCellClickType.ct_Regular);
                                    oForm.Items.Item("1").Visible = false;
                                }
                            }
                            else if (pVal.ItemUID == "btCompReco")
                            {
                                int i = oApplication.MessageBox("Do you really want to proceed?", 1, "Yes", "No");
                                if (i == 1)
                                {
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" UPDATE T0 ");
                                    sbQuery.Append(" SET T0.\"U_RecoCmp\" = 'Y' ");
                                    sbQuery.Append(" FROM \"JDT1\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"TransID\" = T1.\"U_TransID\" AND T0.\"Line_ID\" = T1.\"U_TransLn\" ");
                                    sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' AND T1.\"U_Select\" = 'Y' ");

                                    objclsCommon.SelectRecord(sbQuery.ToString());

                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" UPDATE T0 ");
                                    sbQuery.Append(" SET T0.\"U_Status\" = 'C' ");
                                    sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                                    sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "'   ");
                                    objclsCommon.SelectRecord(sbQuery.ToString());
                                    objclsCommon.RefreshRecord();
                                }
                            }
                            else if (pVal.ItemUID == "btCanReco")
                            {
                                int i = oApplication.MessageBox("Do you really want to proceed?", 1, "Yes", "No");
                                if (i == 1)
                                {
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" UPDATE T0 ");
                                    sbQuery.Append(" SET T0.\"U_RecoCmp\" = 'N' ");
                                    sbQuery.Append(" FROM \"JDT1\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"TransID\" = T1.\"U_TransID\" AND T0.\"Line_ID\" = T1.\"U_TransLn\" ");
                                    sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' AND T1.\"U_Select\" = 'Y' ");

                                    objclsCommon.SelectRecord(sbQuery.ToString());

                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" UPDATE T0 ");
                                    sbQuery.Append(" SET T0.\"U_Status\" = 'L' ");
                                    sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                                    sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "'   ");
                                    objclsCommon.SelectRecord(sbQuery.ToString());
                                    objclsCommon.RefreshRecord();
                                }
                            }

                            else if (pVal.ItemUID == "btRefReco")
                            {
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                double recoAmount = 0;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    string chk = oDbDataSource.GetValue("U_Select", i);
                                    if (chk == "Y")
                                    {
                                        double debit = double.Parse(oDbDataSource.GetValue("U_Debit", i));
                                        double credit = double.Parse(oDbDataSource.GetValue("U_Credit", i));
                                        double amount = debit - credit;
                                        recoAmount = recoAmount + amount;
                                    }
                                }

                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_RecoBal", 0, recoAmount.ToString());

                                double bankBal = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BankBal", 0).ToString());
                                double prevBal = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PrevBal", 0).ToString());

                                double diff = bankBal -(prevBal + recoAmount);
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Diff", 0, diff.ToString());

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else
                {
                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.ItemUID == "1")
                        {
                            string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).Trim();
                            if (docNum == string.Empty)
                            {
                                LoadForm("");
                            }
                        }
                    }
                    if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.DataTable oDataTable = null;
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }
                        if (oCFLEvento.ChooseFromListUID == "CFL_ACC")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            string accountCode = oDataTable.GetValue(CommonFields.AcctCode, 0).ToString();
                            oDbDataSource.SetValue("U_BankGL", 0, oDataTable.GetValue(CommonFields.AcctCode, 0).ToString());
                            GetPreviousBalance(accountCode);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal)
        {
            if (pVal.BeforeAction == false)
            {
                if (pVal.MenuUID == "BANKRECO" || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        EnableDisableButtons();
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        public void LoadForm(string formMenuID)
        {
            if (menuID == formMenuID)
            {
                objclsCommon.LoadXML("BRECO", "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
            }
            oForm = oApplication.Forms.ActiveForm;
            oEdit = oForm.Items.Item("U_Date").Specific;
            oEdit.String = "t";
            oMatrix = oForm.Items.Item(matrixUID).Specific;
            //oMatrix.AddRow(1, 1);

            string autoCode = objclsCommon.SelectRecord("SELECT MAX(Cast(DocNum as numeric(19,6))) FROM \"" + headerTable + "\"");
            int iAutoCode = autoCode == string.Empty ? 1 : int.Parse(autoCode);
            iAutoCode = iAutoCode + 1;
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, iAutoCode.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Status", 0, "P");
            oForm.Items.Item("DocNum").EnableinFindMode();
            oForm.Items.Item("U_BankGL").EnableinAddMode();
            oForm.Items.Item("U_Status").EnableinFindMode();
            EnableDisableButtons();
            oForm.Items.Item("btCompReco").Disable();
            oForm.Items.Item("1").Visible = false;
        }

        void EnableDisableButtons()
        {
            string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Status", 0).Trim();
            string diff = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Diff", 0).Trim();
            double dblDiff = diff == string.Empty ? 0 : double.Parse(diff);
            oForm.Items.Item("btLoad").Enable();
            oForm.Items.Item("btSDraft").Enable();
            oForm.Items.Item("btCompReco").Enable();
            oForm.Items.Item("btCanReco").Enable();

            if (dblDiff != 0)
            {
                oForm.Items.Item("btCompReco").Disable();
            }
            if (status == "P")
            {
                oForm.Items.Item("btCanReco").Disable();
            }
            else if (status == "C")
            {
                oForm.Items.Item("btLoad").Disable();
                oForm.Items.Item("btSDraft").Disable();
                oForm.Items.Item("btCompReco").Disable();
            }
            else if (status == "L")
            {
                oForm.Items.Item("btLoad").Disable();
                oForm.Items.Item("btSDraft").Disable();
                oForm.Items.Item("btCompReco").Disable();
                oForm.Items.Item("btCanReco").Disable();
            }
        }

        void LoadData(string acctcode)
        {
            sbQuery.Length = 0;
            string dataTableUID = "dtJE";
            SAPbouiCOM.DataTable dataTable;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call PROC_BANK_RECO_LOAD_DATA('" + acctcode + "')");
            }
            else
            {
                sbQuery.Append("EXEC PROC_BANK_RECO_LOAD_DATA '" + acctcode + "' ");
            }
            try
            {
                oForm.DataSources.DataTables.Add(dataTableUID);
            }
            catch
            {
            }
            dataTable = oForm.DataSources.DataTables.Item(dataTableUID);
            dataTable.ExecuteQuery(sbQuery.ToString());

            oMatrix = oForm.Items.Item(matrixUID).Specific;
            oMatrix.Clear();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            oDbDataSource.Clear();
            #region Bind With DataTable
            for (int row = 0; row < dataTable.Rows.Count; row++)
            {
                oDbDataSource.InsertRecord(row);
                oDbDataSource.SetValue("U_Select", row, dataTable.GetValue("Chk", row).ToString());
                oDbDataSource.SetValue("U_TransID", row, dataTable.GetValue("TransID", row).ToString());
                oDbDataSource.SetValue("U_TransLn", row, dataTable.GetValue("Line_ID", row).ToString());
                oDbDataSource.SetValue("U_PartyNm", row, dataTable.GetValue("PartyName", row).ToString());
                oDbDataSource.SetValue("U_ChequeNo", row, dataTable.GetValue("ChequeNo", row).ToString());
                oDbDataSource.SetValue("U_Debit", row, dataTable.GetValue("Debit", row).ToString());
                oDbDataSource.SetValue("U_Credit", row, dataTable.GetValue("Credit", row).ToString());
                oDbDataSource.SetValue("U_Remark", row, dataTable.GetValue("Remark", row).ToString());
                try
                {
                    DateTime dt = DateTime.Parse(dataTable.GetValue("RefDate", row).ToString());
                    oDbDataSource.SetValue("U_TransDt", row, dt.ToString("yyyyMMdd"));
                }
                catch (Exception ex)
                {

                }
            }
            #endregion

            oMatrix.LoadFromDataSource();

        }

        void GetPreviousBalance(string acctcode)
        {
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call PROC_ACCOUNT_PREVIOUS_BALANCE('" + acctcode + "')");
            }
            else
            {
                sbQuery.Append("EXEC PROC_ACCOUNT_PREVIOUS_BALANCE '" + acctcode + "' ");
            }
            string bal = objclsCommon.SelectRecord(sbQuery.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PrevBal", 0, bal);
        }

    }
}
