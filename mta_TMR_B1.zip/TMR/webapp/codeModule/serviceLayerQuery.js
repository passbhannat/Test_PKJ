sap.ui.define([
	"TMR/TMR/codeModule/messages"
], function (message) {
	return {
		setConnection: function () {
			var user = "acomi\\pkj";
			var pass = "VVpipapspk1!";
			var comp = "SMA_SBODEMODK";
			var jData = JSON.stringify({
				CompanyDB: comp,
				UserName: user,
				Password: pass
			});
			var serviceLayerLoginURL = "https://b3hsl.acomi.dk/b1s/v1/Login";
			$.ajax({
				url: serviceLayerLoginURL,
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				dataType: "json",
				type: "POST",
				success: function (result, xhr) {
					message.success("Connected with SAP system");
				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
		},
		_getOdata: function (urlIn) {
			var oDataOut;
			$.ajax({
				url: urlIn,
				xhrFields: {
					withCredentials: true
				},
				type: "GET",
				dataType: "json",
				async: false,
				success: function (oData, oResponse) {
					oDataOut = oData;
				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
			return oDataOut;
		},
		_patchData: function (url, jData, status,docEntry) {
			$.ajax({
				url: url,
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				dataType: "json",
				async: false,
				//	"B1S-ReplaceCollectionsOnPatch": true,
				type: "PATCH",
				success: function (result, xhr) {
					
					if (status === 1) {
						message.success("Order: " + docEntry + " is stopped now.");
					} else {
						message.success("Order: " + docEntry + " is started now.");
					}

				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
		},
		_postData: function (url, jData) {
			$.ajax({
				url: url,
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				async: false,
				dataType: "json",
				//	"B1S-ReplaceCollectionsOnPatch": true,
				type: "POST",
				success: function (result, xhr) {
					message.success("Success: Data posted in SAP");
				},
				error: function (oError) {
					message.error("Error: " + oError.responseJSON.error.message.value);
				}
			});
		}
	};
});