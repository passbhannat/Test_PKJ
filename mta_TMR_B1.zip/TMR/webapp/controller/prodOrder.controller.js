sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"TMR/TMR/codeModule/messages",
	"TMR/TMR/codeModule/serviceLayerQuery",
	'sap/ui/core/Fragment',
	"sap/ui/core/syncStyleClass",
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
], function (Controller, History, message, Query, Fragment, syncStyleClass, JSONModel, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("TMR.TMR.controller.prodOrder", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf TMR.TMR.view.prodOrder
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("prodOrder").attachMatched(this._onRouteMatched, this);

		},
		_onRouteMatched: function (oEvent) {
			var type = oEvent.getParameter("arguments").Type;
			var id = oEvent.getParameter("arguments").ID;
			this.getView().byId("idType").setValue(type);
			this.getView().byId("idID").setValue(id);
			this._getProductionOrder();

			//	var resourceVal = emplResousrce.Value(Resources / ResourceEmployees / Code);

		},
		_getProductionOrder: function () {
			var type = this.getView().byId("idType").getValue();
			var id = this.getView().byId("idID").getValue();
			switch (type) {
			case "E":
				var resourceEmpUrl = " ";
				var urlEmplResource =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(Resources,Resources/ResourceEmployees)?$expand=Resources/ResourceEmployees($select=Code)&$filter=Resources/Code  eq  Resources/ResourceEmployees/Code    and  Resources/ResourceEmployees/Employee eq " +
					"'" + id.toString() + "'";
				var emplResource = Query._getOdata(urlEmplResource);
				$.each(emplResource.value, function (i, value) {
					resourceEmpUrl = resourceEmpUrl + "or ProductionOrders/ProductionOrderLines/ItemNo eq '" + value["Resources/ResourceEmployees"]
						.Code + "'";
				});
				var oDataEmpOrdToProcess;
				var urlToProcess =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines,ProductionOrders/ProductionOrdersStages)?$expand=ProductionOrders($select=AbsoluteEntry,DocumentNumber,ItemNo,PlannedQuantity,DueDate,StartDate),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,U_TMR_Status),ProductionOrders/ProductionOrdersStages($select=DocEntry,Name)&$filter=ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry  and ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry eq ProductionOrders/ProductionOrdersStages/DocEntry and ProductionOrders/ProductionOrderLines/StageID eq ProductionOrders/ProductionOrdersStages/StageID and  ProductionOrders/ProductionOrderStatus eq 'R'and ProductionOrders/ProductionOrderLines/U_TMR_Status eq 0 and (ProductionOrders/ProductionOrderLines/ItemNo eq 'XXXXX'" +
					resourceEmpUrl + ")";
				oDataEmpOrdToProcess = Query._getOdata(urlToProcess);
				var oModel = new sap.ui.model.json.JSONModel(oDataEmpOrdToProcess);
				var oTableEmpToProcess = this.getView().byId("idOrdToProcess");
				oTableEmpToProcess.setModel(oModel);
				var oDataEmpOrdInProcess;
				var urlInProcess =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines,ProductionOrders/ProductionOrdersStages)?$expand=ProductionOrders($select=AbsoluteEntry,DocumentNumber,ItemNo,PlannedQuantity,DueDate,StartDate),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,U_TMR_Status),ProductionOrders/ProductionOrdersStages($select=DocEntry,Name)&$filter=ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry  and ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry eq ProductionOrders/ProductionOrdersStages/DocEntry and ProductionOrders/ProductionOrderLines/StageID eq ProductionOrders/ProductionOrdersStages/StageID and  ProductionOrders/ProductionOrderStatus eq 'R'and ProductionOrders/ProductionOrderLines/U_TMR_Status eq 1 and (ProductionOrders/ProductionOrderLines/ItemNo eq 'XXXXX'" +
					resourceEmpUrl + ")";
				oDataEmpOrdInProcess = Query._getOdata(urlInProcess);
				oModel = new sap.ui.model.json.JSONModel(oDataEmpOrdInProcess);
				var oTableEmpInProcess = this.getView().byId("idOrdInProcess");

				oTableEmpInProcess.setModel(oModel);
				break;
			case "M":
				var resourceMchinUrl = " ";
				var urlMchinResource =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(Resources,Resources/ResourceFixedAssets)?$expand=Resources/ResourceFixedAssets($select=Code)&$filter=Resources/Code  eq  Resources/ResourceFixedAssets/Code and Resources/ResourceFixedAssets/ItemCode  eq " +
					"'" + id.toString() + "'";
				var mchinResousrce = Query._getOdata(urlMchinResource);
				$.each(mchinResousrce.value, function (i, value) {
					resourceMchinUrl = resourceMchinUrl + "or ProductionOrders/ProductionOrderLines/ItemNo eq '" + value[
						"Resources/ResourceFixedAssets"].Code + "'";
				});
				var oDataMchinToProcess;
				var urlMchinToProcess =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines,ProductionOrders/ProductionOrdersStages)?$expand=ProductionOrders($select=AbsoluteEntry,DocumentNumber,ItemNo,PlannedQuantity,DueDate,StartDate),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,U_TMR_Status),ProductionOrders/ProductionOrdersStages($select=DocEntry,Name)&$filter=(ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry  and ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry eq ProductionOrders/ProductionOrdersStages/DocEntry and ProductionOrders/ProductionOrderLines/StageID eq ProductionOrders/ProductionOrdersStages/StageID and  ProductionOrders/ProductionOrderStatus eq 'R'and ProductionOrders/ProductionOrderLines/U_TMR_Status eq 0 and ProductionOrders/ProductionOrderLines/ItemNo eq '" +
					id.toString() + "')";
				// + resourceMchinUrl + ")";
				oDataMchinToProcess = Query._getOdata(urlMchinToProcess);
				var oTableMchinToProcess = this.getView().byId("idOrdToProcess");
				var oModelMchin = new sap.ui.model.json.JSONModel(oDataMchinToProcess);
				oTableMchinToProcess.setModel(oModelMchin);
				var oDataMchinInProcess;
				var urlMchinInProcess =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines,ProductionOrders/ProductionOrdersStages)?$expand=ProductionOrders($select=AbsoluteEntry,DocumentNumber,ItemNo,PlannedQuantity,DueDate,StartDate),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,U_TMR_Status),ProductionOrders/ProductionOrdersStages($select=DocEntry,Name)&$filter=(ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry  and ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry eq ProductionOrders/ProductionOrdersStages/DocEntry and ProductionOrders/ProductionOrderLines/StageID eq ProductionOrders/ProductionOrdersStages/StageID and  ProductionOrders/ProductionOrderStatus eq 'R'and ProductionOrders/ProductionOrderLines/U_TMR_Status eq 1 and ProductionOrders/ProductionOrderLines/ItemNo eq '" +
					id.toString() + "')";
				//	resourceMchinUrl + "')";
				oDataMchinInProcess = Query._getOdata(urlMchinInProcess);
				var oTableMchinInProcess = this.getView().byId("idOrdInProcess");
				oModelMchin = new sap.ui.model.json.JSONModel(oDataMchinInProcess);
				oTableMchinInProcess.setModel(oModelMchin);
				break;
			case "R":
				var oDataRoutToProcess;
				var urlRoutToProcess =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines,ProductionOrders/ProductionOrdersStages)?$expand=ProductionOrders($select=AbsoluteEntry,DocumentNumber,ItemNo,PlannedQuantity,DueDate,StartDate),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,U_TMR_Status),ProductionOrders/ProductionOrdersStages($select=DocEntry,Name)&$filter=ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry and ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrdersStages/DocEntry and ProductionOrders/ProductionOrdersStages/StageID eq ProductionOrders/ProductionOrderLines/StageID  and ProductionOrders/ProductionOrderLines/U_TMR_Status eq 0 and ProductionOrders/ProductionOrdersStages/Name eq '" +
					id + "'";
				oDataRoutToProcess = Query._getOdata(urlRoutToProcess);
				var oTableRoutToProcess = this.getView().byId("idOrdToProcess");
				var oModelRout = new sap.ui.model.json.JSONModel(oDataRoutToProcess);
				oTableRoutToProcess.setModel(oModelRout);
				var oDataRoutInProcess;
				var urlRoutInProcess =
					"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines,ProductionOrders/ProductionOrdersStages)?$expand=ProductionOrders($select=AbsoluteEntry, DocumentNumber,ItemNo,PlannedQuantity,DueDate,StartDate),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,U_TMR_Status),ProductionOrders/ProductionOrdersStages($select=DocEntry,Name)&$filter=ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry and ProductionOrders/ProductionOrderStatus eq 'R' and ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrdersStages/DocEntry and ProductionOrders/ProductionOrdersStages/StageID eq ProductionOrders/ProductionOrderLines/StageID and  ProductionOrders/ProductionOrderStatus eq 'R'  and ProductionOrders/ProductionOrderLines/U_TMR_Status eq 1 and ProductionOrders/ProductionOrdersStages/Name eq '" +
					id + "'";
				oDataRoutInProcess = Query._getOdata(urlRoutInProcess);
				var oTableRoutInProcess = this.getView().byId("idOrdInProcess");
				oModelRout = new sap.ui.model.json.JSONModel(oDataRoutInProcess);
				oTableRoutInProcess.setModel(oModelRout);
				break;
			default:
			}
		},
		onStart: function (oEvent) {
			var oDataOrderToStart = oEvent.getSource().getBindingContext().getProperty();
			//var docNumber = oDataOrderToStart.ProductionOrders.DocumentNumber;
			var docEntry = oDataOrderToStart.ProductionOrders.AbsoluteEntry;
			var lineNum = oDataOrderToStart["ProductionOrders/ProductionOrderLines"].LineNumber;
			var itemCode = oDataOrderToStart["ProductionOrders/ProductionOrderLines"].ItemNo;
			//var postURL = "https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines)?$expand=ProductionOrders($select=),ProductionOrders/ProductionOrderLines($select=U_TMR_Status)&$filter=(ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry and ProductionOrders/AbsoluteEntry eq 55 and ProductionOrders/ProductionOrderLines/LineNumber eq 4)";
			var patchURL = "https://b3hsl.acomi.dk/b1s/v1/ProductionOrders(" + docEntry + ")" + "?B1S-ReplaceCollectionsOnPatch eq true";
			var postData = JSON.stringify({
				"ProductionOrderLines": [{
					"LineNumber": lineNum,
					"ItemNo": itemCode,
					"U_TMR_Status": 1
				}]

			});
			Query._patchData(patchURL, postData, 0, docEntry);
			this._getProductionOrder();

		},
		onStop: function (oEvent) {
			var oDataOrderToStop = oEvent.getSource().getBindingContext().getProperty();
			var docEntry = oDataOrderToStop.ProductionOrders.AbsoluteEntry;
			var lineNum = oDataOrderToStop["ProductionOrders/ProductionOrderLines"].LineNumber;
			var itemCode = oDataOrderToStop["ProductionOrders/ProductionOrderLines"].ItemNo;
			var patchURL = "https://b3hsl.acomi.dk/b1s/v1/ProductionOrders(" + docEntry + ")" + "?B1S-ReplaceCollectionsOnPatch eq true";
			var postData = JSON.stringify({
				"ProductionOrderLines": [{
					"LineNumber": lineNum,
					"ItemNo": itemCode,
					"U_TMR_Status": 2
				}]

			});
			Query._patchData(patchURL, postData, 1, docEntry);
			this._getProductionOrder();
		},
		onComp: function () {

			var jData = JSON.stringify({
				"Document": {
					"Comments": "TMR",
					"DocDate": "20200524",
					"DocDueDate": "20200524",
					"DocumentLines": [{
						"ItemCode": "PLA3000",
						"Quantity": 1,
						//"UnitPrice": "10",
						"BaseType": 202,
						"BaseEntry": 44,
						"BaseLine": null,
						"WarehouseCode": "MD01",
						"DocumentLinesBinAllocations": [{
							"AllowNegativeQuantity": "Y",
							"BinAbsEntry": "2",
							"Quantity": 1
						}]

					}]
				}
			});

			var grPostURL = "https://b3hsl.acomi.dk/b1s/v1/InventoryGenEntries";
			Query._postData(grPostURL, jData);
		},
		onNavBack: function () {

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View1", true);
			}
		},
		onExit: function () {
			if (this._oDialog) {
				this._oDialog.destroy();
			}
		},
		onPressShowPOItemModal: function (oEvent) {

			var oButton = oEvent.getSource();
			if (!this._oDialog) {
				Fragment.load({
					name: "TMR.TMR.view.Dialog",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					this._configDialog(oButton);
					this._oDialog.open();
				}.bind(this));
			} else {
				this._configDialog(oButton);
				this._oDialog.open();
			}
		},
		_configDialog: function (oButton) {

			// Set resizable property
			var bResizable = oButton.data("resizable");
			this._oDialog.setResizable(bResizable == "true");

			this._oDialog.setMultiSelect(true);

			var sResponsivePadding = oButton.data("responsivePadding");
			var sResponsiveStyleClasses =
				"sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";

			if (sResponsivePadding) {
				this._oDialog.addStyleClass(sResponsiveStyleClasses);
			} else {
				this._oDialog.removeStyleClass(sResponsiveStyleClasses);
			}

			// Set custom text for the confirmation button
			var sCustomConfirmButtonText = oButton.data("confirmButtonText");
			this._oDialog.setConfirmButtonText(sCustomConfirmButtonText);

			this.getView().addDependent(this._oDialog);

			// toggle compact style
			syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);

			var oData;
			var url =
				"https://b3hsl.acomi.dk/b1s/v1/$crossjoin(ProductionOrders,ProductionOrders/ProductionOrderLines)?$expand=ProductionOrders($select=AbsoluteEntry, DocumentNumber),ProductionOrders/ProductionOrderLines($select=ItemNo,LineNumber,PlannedQuantity)&$filter=ProductionOrders/AbsoluteEntry eq ProductionOrders/ProductionOrderLines/DocumentAbsoluteEntry and ProductionOrders/AbsoluteEntry eq 64 ";
			oData = Query._getOdata(url);
			//var dialog = sap.ui.xmlfragment("Dialog", "TMR.TMR.view.Dialog");
			//var oTable = sap.ui.core.Fragment.byId("TMR.TMR.view.Dialog", "idPOModalTable");
			var oTable = sap.ui.getCore().byId("idPOModalTable");

			var list = [];
			$.each(oData.value, function (i, item) {
				list.push({
					"DocumentNumber": item["ProductionOrders"].DocumentNumber,
					"ItemNo": item["ProductionOrders/ProductionOrderLines"].ItemNo,
					"PlannedQuantity": item["ProductionOrders/ProductionOrderLines"].PlannedQuantity,
					"Quantity": item["ProductionOrders/ProductionOrderLines"].PlannedQuantity,
				});
			});
			var oModel = new sap.ui.model.json.JSONModel({
				"value": list,
			});
			//var oTable = sap.ui.core.Fragment.byId(fragmentId, "idPOModalTable");
			//var oTable = this.getView().byId("idPOModalTable");
			//var oModel = new sap.ui.model.json.JSONModel(oData);
			oTable.setModel(oModel);

		},
		handleSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Name", FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleClose: function (oEvent) {
			// reset the filter
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);

			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				//	MessageToast.show("You have chosen " + aContexts.map(function (oContext) { return oContext.getObject().Name; }).join(", "));
			}
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf TMR.TMR.view.prodOrder
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf TMR.TMR.view.prodOrder
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf TMR.TMR.view.prodOrder
		 */
		//	onExit: function() {
		//
		//	}

	});

});