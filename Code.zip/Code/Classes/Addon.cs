﻿using System;
using System.Data.SqlClient;
using Company = SAPbobsCOM.Company;

namespace CompanyTransfer
{
    /// <summary>
    ///     Add-On framework main class defines method to initialize the framework
    /// </summary>
    public static class Addon
    {
        #region Add-On framework Properties

        public static Company Company;

        #endregion

        public static void Init()
        {
            if (Addon.Company == null)
            {
                SAPLogin();
            }
            PrepareDatabase();
        }

        public static string SAPLogin()
        {
            string SQLConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["sapConnectionString"].ToString();
            Company = new SAPbobsCOM.Company();

            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(SQLConnectionString);
                Company.LicenseServer = System.Configuration.ConfigurationManager.AppSettings["LicenseServer"].ToString() + ":30000";
                Company.Server = builder.DataSource;
                Company.CompanyDB = builder.InitialCatalog;
                Company.DbUserName = builder.UserID;
                Company.DbPassword = builder.Password;
                Company.UserName = System.Configuration.ConfigurationManager.AppSettings["SAPUserCode"].ToString();
                Company.Password = System.Configuration.ConfigurationManager.AppSettings["SAPPassword"].ToString();
                SAPbobsCOM.BoDataServerTypes boDataServerTypes;
                Enum.TryParse(System.Configuration.ConfigurationManager.AppSettings["DBServerType"].ToString(), out boDataServerTypes);
                Company.DbServerType = boDataServerTypes;
                int i = Company.Connect();
                if (i == 0)
                {
                    return i.ToString();
                }
                else
                {
                    long ErrorCode = Company.GetLastErrorCode();
                    string ErrorMessage = string.Empty;
                    if (ErrorCode == -10 || ErrorCode == -8037)
                    {
                        ErrorMessage = ErrorCode.ToString() + " - Network issue!!! Please try again.";
                    }
                    else if (ErrorCode == -132)
                    {
                        ErrorMessage = ErrorCode.ToString() + " - Incorrect login id/password, please try again";
                    }
                    else if (ErrorCode == 100000048)
                    {
                        return ErrorCode.ToString();
                    }
                    else
                    {
                        ErrorMessage = Company.GetLastErrorCode() + " : " + Company.GetLastErrorDescription();
                    }
                    return ErrorMessage;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private static void PrepareDatabase()
        {
            var database = new Database();
            database.PrepareDatabase();
        }
    }
}