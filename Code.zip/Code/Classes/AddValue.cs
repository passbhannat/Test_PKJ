﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CompanyTransfer
{
    public class AddValue
    {
        private string m_Display;
        private string m_Value;
        public AddValue(string Display, string Value)
        {
            m_Display = Display;
            m_Value = Value;
        }
        public string Display
        {
            get { return m_Display; }
           // set { m_Display =; Display}
        }
        public string Value
        {
            get { return m_Value; }
          //  set { m_Value = Value; }
        }
      
    }
}
