﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyTransfer
{
    public partial class frmBusinessPartner : Form
    {
        clsDataAccess objclsDataAccess = new clsDataAccess();
        public bool isopen = false;

        public frmBusinessPartner()
        {
            InitializeComponent();
        }

        private void BusinessPartner_Load(object sender, EventArgs e)
        {
            isopen = true;
            objclsDataAccess.Fill_Combo_Value_Display(cmbCompany, "SELECT Code,Name FROM [@SAP_DATABASE]", "Code", "Name");

            DataSet ds = FillBusinessPartner();
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
        }

        private DataSet FillBusinessPartner()
        {
            SqlConnection con = new SqlConnection();
            con = objclsDataAccess.OpenConnection();
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ROW_NUMBER() OVER(ORDER BY name ASC) AS Row, ");
            sbQuery.Append(" Code,U_primary_key [Primary Key],U_operation [Operation], Convert(Varchar(10), U_timestamp,105) Date");
            sbQuery.Append(" FROM [@SAP_QUEUE] ");
            sbQuery.Append(" WHERE U_table_name='OCRD' AND U_status='Ready' ");
            DataSet ds = new DataSet();
            ds = objclsDataAccess.FillDataset(sbQuery.ToString(), con);
            return ds;
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbCompany.Text.Trim()) || cmbCompany.Text == "Select")
            {
                MessageBox.Show("Please select destination company");
                return;
            }
            bool isRowSelected = false;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (dataGridView1.Rows[i].Cells["Chk"].Value == null || (bool)dataGridView1.Rows[i].Cells["Chk"].Value == false)
                {
                    continue;
                }
                isRowSelected = true;
                break;
            }
            if (isRowSelected == false)
            {
                MessageBox.Show("No Rows selected");
                return;
            }
            if (Addon.Company == null)
            {
                Addon.SAPLogin();
            }
            ExportBPToXml();
            ImportBPFromXml();
            DataSet ds = FillBusinessPartner();
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            MessageBox.Show("Process completed!");
        }

        private void ExportBPToXml()
        {
            string xmlFolder = Application.StartupPath + "\\Export";
            if (!System.IO.Directory.Exists(xmlFolder))
            {
                System.IO.Directory.CreateDirectory(xmlFolder);
            }

            DataSet ds = FillBusinessPartner();
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (dataGridView1.Rows[i].Cells["Chk"].Value == null || (bool)dataGridView1.Rows[i].Cells["Chk"].Value == false)
                {
                    continue;
                }
                SAPbobsCOM.BusinessPartners oBP = Addon.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners);
                Addon.Company.XmlExportType = SAPbobsCOM.BoXmlExportTypes.xet_ExportImportMode;
                string cardcode = ds.Tables[0].Rows[i]["Primary Key"].ToString();
                oBP.GetByKey(cardcode);
                string xmlPath = xmlFolder + "\\" + cardcode + ".xml";
                oBP.SaveXML(xmlPath);
            }
        }

        private void ImportBPFromXml()
        {
            string xmlFolder = Application.StartupPath + "\\Export";
            SAPbobsCOM.Company CompanyDestination;
            SAPLoginDestination(out CompanyDestination);
            if (CompanyDestination == null)
            {
                MessageBox.Show("Unable to connect to Destination company");
                return;
            }

            int result = 0;
            bool bpExist = false;
            string query = string.Empty;
            string errorDescription = string.Empty;
            DataSet ds = FillBusinessPartner();
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (dataGridView1.Rows[i].Cells["Chk"].Value == null || (bool)dataGridView1.Rows[i].Cells["Chk"].Value == false)
                {
                    continue;
                }
                string cardcode = ds.Tables[0].Rows[i]["Primary Key"].ToString();
                string code = ds.Tables[0].Rows[i]["Code"].ToString();

                string xmlPath = xmlFolder + "\\" + cardcode + ".xml";

                CompanyDestination.XmlExportType = SAPbobsCOM.BoXmlExportTypes.xet_ExportImportMode;

                SAPbobsCOM.BusinessPartners oBP = CompanyDestination.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners);
                if (oBP.GetByKey(cardcode))
                {
                    bpExist = true;
                }
                oBP = CompanyDestination.GetBusinessObjectFromXML(xmlPath, 0);
                if (bpExist == true)
                {
                    result = oBP.UpdateFromXML(xmlPath);
                }
                else
                {
                    result = oBP.Add();
                }
                if (result == 0)
                {
                    query = "UPDATE [@SAP_QUEUE] SET U_error_desc='', U_Status='Completed' WHERE U_TABLE_NAME='OCRD' AND code='" + code + "'";
                }
                else
                {
                    errorDescription = CompanyDestination.GetLastErrorDescription();
                    errorDescription = errorDescription.Replace("'", "''");
                    query = "UPDATE [@SAP_QUEUE] SET U_error_desc='" + errorDescription + "' WHERE U_TABLE_NAME='OCRD' AND code='" + code + "'";
                }
                objclsDataAccess.GetRecord(query, objclsDataAccess.OpenConnection());
            }
        }

        public string SAPLoginDestination(out SAPbobsCOM.Company CompanyDestination)
        {
            string SQLConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["sapConnectionString"].ToString();
            CompanyDestination = new SAPbobsCOM.Company();

            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(SQLConnectionString);
                CompanyDestination.LicenseServer = System.Configuration.ConfigurationManager.AppSettings["LicenseServer"].ToString() + ":30000";
                CompanyDestination.Server = builder.DataSource;
                CompanyDestination.CompanyDB = cmbCompany.Text;
                CompanyDestination.DbUserName = builder.UserID;
                CompanyDestination.DbPassword = builder.Password;
                CompanyDestination.UserName = System.Configuration.ConfigurationManager.AppSettings["SAPUserCode"].ToString();
                CompanyDestination.Password = System.Configuration.ConfigurationManager.AppSettings["SAPPassword"].ToString();
                SAPbobsCOM.BoDataServerTypes boDataServerTypes;
                Enum.TryParse(System.Configuration.ConfigurationManager.AppSettings["DBServerType"].ToString(), out boDataServerTypes);
                CompanyDestination.DbServerType = boDataServerTypes;
                int i = CompanyDestination.Connect();
                if (i == 0)
                {
                    return i.ToString();
                }
                else
                {
                    long ErrorCode = CompanyDestination.GetLastErrorCode();
                    string ErrorMessage = CompanyDestination.GetLastErrorDescription();
                    return ErrorMessage;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private void FrmBusinessPartner_FormClosing(object sender, FormClosingEventArgs e)
        {
            isopen = false;
        }

        private void DataGridView1_ColumnHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            bool firstChkValue = dataGridView1.Rows[0].Cells["Chk"].Value == null ? false : (bool)dataGridView1.Rows[0].Cells["Chk"].Value;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                dataGridView1.Rows[i].Cells["Chk"].Value = !firstChkValue;
            }
        }

        private void DataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
    }
}
