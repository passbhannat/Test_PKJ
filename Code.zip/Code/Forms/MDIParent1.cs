﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyTransfer
{
    public partial class MDIParent1 : Form
    {
        private int childFormNumber = 0;
        frmItemMaster objfrmItemMaster = new frmItemMaster();
        frmBusinessPartner objfrmBusinessPartner = new frmBusinessPartner();

        public MDIParent1()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void createUDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Addon.Init();
            MessageBox.Show("Process completed!");
        }

        private void itemMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objfrmItemMaster== null || objfrmItemMaster.isopen == false)
            {
                objfrmItemMaster = new frmItemMaster();
                objfrmItemMaster.MdiParent = this;
                objfrmItemMaster.Show();
                objfrmItemMaster.BringToFront();
            }
            else
            {
                objfrmItemMaster.BringToFront();
            }
        }

        private void businessPartnerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (objfrmBusinessPartner == null || objfrmBusinessPartner.isopen == false)
            {
                objfrmBusinessPartner = new frmBusinessPartner();
                objfrmBusinessPartner.MdiParent = this;
                objfrmBusinessPartner.Show();
                objfrmBusinessPartner.BringToFront();
            }
            else
            {
                objfrmBusinessPartner.BringToFront();
            }
        }

        private void MDIParent1_Load(object sender, EventArgs e)
        {

        }
    }
}
