﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Text;
using System.Windows.Forms;

namespace CompanyTransfer
{
    public partial class frmPleaseWait : Form
    {
        public frmPleaseWait()
        {
            InitializeComponent();
        }

        private void frmPleaseWait_Load(object sender, EventArgs e)
        {

        }

        private void frmPleaseWait_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }
    }
}
