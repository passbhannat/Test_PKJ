using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SODocAddon.Classes;
using System.Linq;

namespace SODocAddon.Standard_Forms
{
    class clsServiceContract : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "OCTR";
        const string rowTable = "CTR1";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_SER = "CFL_SER";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "U_SerNo")
                            {
                                string tableName = "OSRN";
                                string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCode", 0).Trim();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T2.\"AbsEntry\"   ");
                                sbQuery.Append(" FROM \"ITL1\" T0 ");
                                sbQuery.Append(" INNER JOIN	\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
                                sbQuery.Append(" INNER JOIN	\"" + tableName + "\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\" ");
                                sbQuery.Append(" WHERE T1.\"ApplyType\" IN ('13','15') AND T2.\"ItemCode\" = '" + itemcode + "'  ");
                                sbQuery.Append("GROUP BY T2.\"AbsEntry\"");

                                objclsCommon.AddChooseFromList_WithQuery(oForm, CFL_SER, "", sbQuery.ToString(), "AbsEntry");
                            }
                            else if (pVal.ItemUID == "94")
                            {
                                string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCode", 0).Trim();
                                string serialNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_SerNo", 0).Trim();
                                SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                                string sCFL_ID = oCFLEvento.ChooseFromListUID;
                               
                            }
                        }
                        #endregion
                         
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);


                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("stItemNo", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            SAPbouiCOM.Item oItem = oForm.Items.Item("234000116");
                            oNewItem.Left = oItem.Left;
                            oNewItem.Top = oForm.Items.Item("10").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            SAPbouiCOM.StaticText oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStaticText.Caption = "Item Description";


                            oNewItem = oForm.Items.Add("U_ItemCode", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("stItemNo");
                            oNewItem.Left = oItem.Left + oItem.Width + 10;
                            oNewItem.Top = oForm.Items.Item("10").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, "U_ItemCode");

                            List<clsCFLEntity> clsCFLs = new List<clsCFLEntity>();
                            clsCFLEntity entity = new clsCFLEntity();
                            entity.Alias = "ManSerNum";
                            entity.Operation = BoConditionOperation.co_EQUAL;
                            entity.CondVal = "Y";
                            clsCFLs.Add(entity);
                            objclsCommon.AddChooseFromList(oForm, CFL_ITEM, "4");
                            objclsCommon.AddChooseFromList_WithList(oForm, CFL_ITEM, clsCFLs);
                            oEdit = oForm.Items.Item("U_ItemCode").Specific;
                            oEdit.ChooseFromListUID = CFL_ITEM;
                            oEdit.ChooseFromListAlias = "ItemCode";

                            oNewItem = oForm.Items.Add("stSerNo", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("stItemNo");
                            oNewItem.Left = oItem.Left;
                            oNewItem.Top = oForm.Items.Item("24").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStaticText.Caption = "Serial No";


                            oNewItem = oForm.Items.Add("U_SerNo", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("U_ItemCode");
                            oNewItem.Left = oItem.Left;
                            oNewItem.Top = oForm.Items.Item("24").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, "U_SerNo");

                            objclsCommon.AddChooseFromList(oForm, CFL_SER, "10000045");
                            oEdit.ChooseFromListUID = CFL_SER;
                            oEdit.ChooseFromListAlias = "DistNumber";

                            oNewItem = oForm.Items.Add("btFI", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("U_SerNo");
                            oNewItem.Left = oItem.Left + oItem.Width + 10;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.Caption = "Fill Items";
                        }

                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oEdit = oForm.Items.Item("U_ItemCode").Specific;
                                try
                                {
                                    oEdit.String = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                }
                                catch { }
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_SER)
                            {
                                oEdit = oForm.Items.Item("U_SerNo").Specific;
                                try
                                {
                                    oEdit.String = oDataTable.GetValue(CommonFields.DistNumber, 0).ToString();
                                }
                                catch { }
                            }
                        }


                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

    }
}
