﻿using ARCAddon.Classes;
using ARCAddon.Extensions;
using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;

namespace ARCAddon.Custom_Form
{
    class clsARC : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Folder oFolder;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@ARC";
        public const string rowTable = "@ARC1";
        public const string objType = "ARC";
        public const string formMenuUID = "ARC";
        const string formTitle = "ARC";
        const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        const string gridSOUID = "grd1";
        const string gridInvoiceUID = "grd2";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                //string name = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                                //if (name == string.Empty)
                                //{
                                //    oApplication.StatusBar.SetText("Customer Code is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                //    BubbleEvent = false;
                                //    return;
                                //}
                                //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                //oMatrix.FlushToDataSource();
                                //if (oMatrix.VisualRowCount == 0)
                                //{
                                //    oApplication.StatusBar.SetText("Row level data is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                //    BubbleEvent = false;
                                //    return;
                                //}
                                //oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                //for (int i = 0; i < oDbDataSource.Size; i++)
                                //{
                                //    //string slabFrom = oDbDataSource.GetValue("U_ItemCode", i);
                                //    //if (slabFrom == string.Empty)
                                //    //{
                                //    //    oApplication.StatusBar.SetText("Item Code is mandatory for Row No: " + (i + 1).ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                //    //    BubbleEvent = false;
                                //    //    return;
                                //    //}
                                //}

                            }

                            else if (pVal.ItemUID == "btGenSO")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Status", 0).Trim();

                                if (status != "O")
                                {
                                    oApplication.StatusBar.SetText("Document should be Open", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                            }
                            else if (pVal.ItemUID == "btCanc")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Status", 0).Trim();
                                if (status == "L")
                                {
                                    oApplication.StatusBar.SetText("Document is already cancelled.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                int i = oApplication.MessageBox("Do you really want to cancel document?", 1, "Yes", "No", "");
                                if (i == 1)
                                {
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                    objclsCommon.SelectRecord("UPDATE \"" + headerTable + "\" SET U_Status = 'L' WHERE DocEntry = '" + docEntry + "'");
                                    objclsCommon.RefreshRecord();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formMenuUID && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).ToString();
                                if (docNum.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }

                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_BP")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                                oDbDataSource.SetValue("U_PayTerms", 0, oDataTable.GetValue(CommonFields.GroupNum, 0).ToString());
                                try
                                {
                                    FillGridSODetails();
                                }
                                catch { }
                                try
                                {
                                    FillGriInvoiceDetails();
                                }
                                catch { }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                string itemcode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                string itemname = oDataTable.GetValue(CommonFields.ItemName, 0).ToString();
                                oDbDataSource.SetValue("U_ItemCode", pVal.Row - 1, itemcode);
                                oDbDataSource.SetValue("U_ItemName", pVal.Row - 1, itemname);

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }
                        #endregion

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "U_ContNo" || pVal.ItemUID == "U_ContFD" || pVal.ItemUID == "U_ContTD" || pVal.ItemUID == "U_ContVal")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string value = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0);
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(pVal.ItemUID, 0, value);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }




        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(menuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oCombo = oForm.Items.Item("U_ContCur").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"CurrCode\", T0.\"CurrName\" FROM OCRN T0");
                    oCombo = oForm.Items.Item("U_PayTerms").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"GroupNum\", T0.\"PymntGroup\" FROM OCTG T0");

                    //oCombo = oForm.Items.Item("U_Branch").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"BPLId\", T0.\"BPLName\" FROM OBPL T0 WHERE \"Disabled\" = 'N' ");

                    List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                    clsCFLEntityList.Add(new clsCFLEntity { Alias = "CardType", CondVal = "C", Operation = BoConditionOperation.co_EQUAL });
                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP", clsCFLEntityList);
                }
                oEdit = oForm.Items.Item("U_ContFD").Specific;
                oEdit.String = "t";
                oEdit = oForm.Items.Item("U_ContTD").Specific;
                oEdit.String = "t";
                //oEdit = oForm.Items.Item("U_PostDate").Specific;
                //oEdit.String = "t";
                oMatrix = oForm.Items.Item(matrixUID).Specific;
                oMatrix.AddRow(1, 1);
                oMatrix.CommonSetting.EnableArrowKey = true;
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.Items.Item("U_Status").EnableinFindMode();

                oFolder = oForm.Items.Item("fld1").Specific;
                oFolder.Select();
                //#region Series And DocNum

                //try
                //{
                //    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                //    oEdit.String = "t";

                //    objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_DocDate", "Load");

                //    #region Set DocNum
                //    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                //    if (defaultseries == string.Empty)
                //    {
                //        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                //        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                //        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                //    }
                //    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                //    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                //    #endregion

                //}
                //catch { }
                //#endregion

                //oForm.Items.Item("DocEntry").EnableinFindMode();
                //string autoCode = objclsCommon.SelectRecord("SELECT MAX(Cast(Code as numeric(19,6))) FROM \"" + headerTable + "\"");
                //int iAutoCode = autoCode == string.Empty ? 1 : int.Parse(autoCode);
                //iAutoCode = iAutoCode + 1;
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Status", 0, "O");
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void FillGridSODetails()
        {
            oForm = oApplication.Forms.ActiveForm;
            string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call PROC_SO_DETAILS ('" + cardcode + "')");
            }
            else
            { 
                sbQuery.Append("EXEC PROC_SO_DETAILS '" + cardcode + "' ");

            }
            objclsCommon.FillGrid(oForm.UniqueID, gridSOUID, gridSOUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridSOUID).Specific;
            for (int i = 0; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
        }

        private void FillGriInvoiceDetails()
        {
            oForm = oApplication.Forms.ActiveForm;
            string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call PROC_INVOICE_DETAILS ('" + cardcode + "')");
            }
            else
            {
                sbQuery.Append("EXEC PROC_INVOICE_DETAILS '" + cardcode + "' ");

            }
            objclsCommon.FillGrid(oForm.UniqueID, gridInvoiceUID, gridInvoiceUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridInvoiceUID).Specific;
            for (int i = 0; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
        }
    }
}
