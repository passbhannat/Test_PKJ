sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"TMR/TMR/codeModule/messages",
	"TMR/TMR/codeModule/serviceLayerQuery"
], function (Controller, message, Query) {
	"use strict";
	return Controller.extend("TMR.TMR.controller.View1", {
		onInit: function () {
			Query.setConnection();
			
			var oSelect = this.getView().byId("idTypeCombo");
			var newItem = new sap.ui.core.Item({
				key: "E",
				text: "Employee"
			});
			oSelect.addItem(newItem);
			newItem = new sap.ui.core.Item({
				key: "M",
				text: "Machine"
			});
			oSelect.addItem(newItem);
			newItem = new sap.ui.core.Item({
				key: "R",
				text: "Routing States"
			});
			oSelect.addItem(newItem);
		},
		onCreateUDF: function(oEvent){
			Query._createUDFs();
		},
		
		onPressGo: function (oEvent) {
			var type = this.getView().byId("idTypeCombo").getSelectedKey();
			if (type === "") {
				message.error("Please select Type");
				return;
			}
			
			var id = this.getView().byId("idValues").getSelectedKey();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//oRouter.navTo("View2");
			oRouter.navTo("prodOrder",{Type:type,ID: id });
		},
		// onPressValues: function (url) {
		// 	var type = this.getView().byId("idTypeCombo").getValue();
		// 	if (type == "") {
		// 		message.error("Please select Type");
		// 		//return;
		// 	}
		// 	var serviceLayerURL = url;
		// 	var that = this;
		// 	$.ajax({
		// 		url: serviceLayerURL,
		// 		xhrFields: {
		// 			withCredentials: true
		// 		},
		// 		// data: jData,
		// 		type: "GET",
		// 		dataType: "json",
		// 		async: false,
		// 		success: function (oData, oResponse) {
		// 			var oComboValue = that.byId("idValues");
		// 			$.each(oData.value, function (i, value) {
		// 				var oItem = new sap.ui.core.ListItem();
		// 				oItem.setText(value.Description);
		// 				oItem.setKey(value.Code);
		// 				oComboValue.addItem(oItem);
		// 			});
		// 		},
		// 		error: function (oError) {
		// 			message.error("Error: " + oError.responseJSON.error.message.value);
		// 		}
		// 	});
		// },
		onChangeType: function (oEvent) {
			var type = this.getView().byId("idTypeCombo").getSelectedKey();
			var oComboValue = this.getView().byId("idValues");
			oComboValue.removeAllItems();
			var oDataIn;
			if (type == null) {
				message.error("Please select Type");
				return;
			}
			var url = "https://b3hsl.acomi.dk/b1s/v1/";
			if (type === "E") {
				url = url + "EmployeesInfo?$select=EmployeeID,FirstName";
				oDataIn = Query._getOdata(url);
				//var oModel = new sap.ui.model.json.JSONModel(oDataIn);
				//oComboValue.setModel(oModel);
				$.each(oDataIn.value, function (i, value) {
					var oItem = new sap.ui.core.ListItem();
					oItem.setAdditionalText(value.FirstName);
					oItem.setText(value.EmployeeID);
					oItem.setKey(value.EmployeeID);
					oComboValue.addItem(oItem);
				});
			} else if (type === "M") {
				url = url + "Resources?$select=Code,Name&$filter=(Type eq  'rtMachine')";
				oDataIn = Query._getOdata(url);
				$.each(oDataIn.value, function (i, value) {
					var oItem = new sap.ui.core.ListItem();
					oItem.setAdditionalText(value.Name);
					oItem.setText(value.Code);
					oItem.setKey(value.Code);
					oComboValue.addItem(oItem);
				});
			} else if (type === "R") {
				url = url + "RouteStages?$select=Code,Description";
				oDataIn = Query._getOdata(url);
				$.each(oDataIn.value, function (i, value) {
					var oItem = new sap.ui.core.ListItem();
					oItem.setAdditionalText(value.Code);
					oItem.setText(value.Description);
					oItem.setKey(value.Description);
					oComboValue.addItem(oItem);
				});
			}
		},
		/**
		 *@memberOf TMR.TMR.controller.View1
		 */
		// action: function (oEvent) {
		// 	var that = this;
		// 	var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
		// 	var eventType = oEvent.getId();
		// 	var aTargets = actionParameters[eventType].targets || [];
		// 	aTargets.forEach(function (oTarget) {
		// 		var oControl = that.byId(oTarget.id);
		// 		if (oControl) {
		// 			var oParams = {};
		// 			for (var prop in oTarget.parameters) {
		// 				oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
		// 			}
		// 			oControl[oTarget.action](oParams);
		// 		}
		// 	});
		// 	var oNavigation = actionParameters[eventType].navigation;
		// 	if (oNavigation) {
		// 		var oParams = {};
		// 		(oNavigation.keys || []).forEach(function (prop) {
		// 			oParams[prop.name] = encodeURIComponent(JSON.stringify({
		// 				value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
		// 				type: prop.type
		// 			}));
		// 		});
		// 		if (Object.getOwnPropertyNames(oParams).length !== 0) {
		// 			this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
		// 		} else {
		// 			this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
		// 		}
		// 	}
		// }
	});
});