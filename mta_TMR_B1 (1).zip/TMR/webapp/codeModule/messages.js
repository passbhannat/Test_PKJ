sap.ui.define([
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (MessageBox, MessageToast) {
	return {
		confirm: function (msg) {
			MessageBox.confirm(msg);
		},
		alert: function (msg) {
			MessageBox.alert(msg);
		},
		error: function (msg) {
			MessageBox.error(msg);
		},
		information: function (msg) {
			MessageBox.information(msg);
		},
		warning: function (msg) {
			MessageBox.warning(msg);
		},
		success: function (msg) {
			MessageBox.success(msg);
		},
		informationPadding: function (msg) {
			MessageBox.information(msg, {
				styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
			});
		},
		errorAction: function (msg) {
			MessageBox.error(msg, {
				actions: ["Yes", MessageBox.Action.CLOSE],
				emphasizedAction: "Yes",
				onClose: function (sAction) {
					MessageToast.show("Action selected: " + sAction);
				}
			});
		},
		warningAction: function (msg) {
			MessageBox.warning(msg, {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					MessageToast.show("Action selected: " + sAction);
				}
			});
		}
	};
});