using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SODocAddon.Classes;
using System.Linq;

namespace SODocAddon.Standard_Forms
{
    class clsIssueForProduction : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string matrixUID = "13";
        const string headerTable = "OIGE";
        const string rowTable = "IGE1";
        const string CFL_SER = "CFL_SER";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                                {
                                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                                    string docnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", 1)).String;
                                    string series = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", 1)).Value.Trim();
                                    string prodItemCode = objclsCommon.SelectRecord("SELECT \"ItemCode\" FROM OWOR WHERE \"DocNum\" = '" + docnum + "' AND \"Series\" = '" + series + "'");
                                    string prodType = objclsCommon.SelectRecord("SELECT \"Type\" FROM OWOR WHERE \"DocNum\" = '" + docnum + "' AND \"Series\" = '" + series + "'");
                                    string itemGroup = objclsCommon.SelectRecord("SELECT \"ItmsGrpNam\" FROM OITM T0 INNER JOIN OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" WHERE \"ItemCode\" = '" + prodItemCode + "' ");
                                    string serialNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_SerNo", 0).Trim();
                                    if (prodType != "S")
                                    {
                                        return;
                                    }
                                    if (itemGroup.ToLower() == "finish goods")
                                    {
                                        if (serialNo == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Serial No is compulsary ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                            return;
                                        }
                                        for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                        {
                                            docnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", i)).String;
                                            series = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", i)).Value.Trim();
                                            string rowNo = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("60", i)).String;

                                            string itemcode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                            string rowQuantity = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", i)).String;
                                            double dblRowQuantity = rowQuantity == string.Empty ? 0 : double.Parse(rowQuantity);

                                            string prodDocEntry = objclsCommon.SelectRecord("SELECT \"DocEntry\" FROM OWOR WHERE \"DocNum\" = '" + docnum + "' AND \"Series\" = '" + series + "'");
                                            string componentBaseQty = objclsCommon.SelectRecord("SELECT \"BaseQty\" FROM WOR1 WHERE \"DocEntry\" = '" + prodDocEntry + "' AND \"ItemCode\" = '" + itemcode + "'");
                                            double dblComponentBaseQty = componentBaseQty == string.Empty ? 0 : double.Parse(componentBaseQty);
                                            if (dblComponentBaseQty != dblRowQuantity)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Issue quantity should match with base quantity of PO. Row No: " + rowNo, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                                return;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (serialNo != string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please remove serial no. It is applicable only for finish goods ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                            return;
                                        }
                                    }
                                }
                            }
                            else if (pVal.ItemUID == "btTC")
                            {

                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                //clsTravellerCard _clsTravellerCard = new clsTravellerCard();
                                //_clsTravellerCard.LoadForm(clsTravellerCard.formMenuUID, docEntry);
                            }
                        }


                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "U_SerNo")
                            {
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                string docnum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", 1)).String;
                                string series = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", 1)).Value.Trim();
                                string productionDocEntry = objclsCommon.SelectRecord("SELECT \"DocEntry\" FROM OWOR WHERE \"DocNum\" = '" + docnum + "' AND \"Series\" = '" + series + "'");
                                string receiptDocEntry = objclsCommon.SelectRecord("SELECT \"DocEntry\" FROM IGN1 WHERE \"BaseEntry\" = '" + productionDocEntry + "' AND \"BaseType\" = '202' ");

                                if (docnum == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select production no", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }

                                string tableName = "OSRN";
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T2.\"AbsEntry\"   ");
                                sbQuery.Append(" FROM \"ITL1\" T0 ");
                                sbQuery.Append(" INNER JOIN	\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
                                sbQuery.Append(" INNER JOIN	\"" + tableName + "\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\" ");
                                sbQuery.Append(" WHERE T1.\"ApplyEntry\" = '" + receiptDocEntry + "' AND T1.\"ApplyType\" = '" + 59 + "' ");

                                sbQuery.Append(" AND NOT EXISTS(SELECT 1 FROM OIGE IT0 ");
                                sbQuery.Append(" INNER JOIN IGE1 IT1 ON IT0.\"DocEntry\" = IT1.\"DocEntry\" ");
                                sbQuery.Append(" WHERE IT0.\"U_SerNo\" = T2.\"DistNumber\" ) ");
                                sbQuery.Append("GROUP BY T2.\"AbsEntry\"");

                                //sbQuery.Append(objclsCommon.GetSeriesQuery_ApplyType(ManageItemType.Series,receiptDocEntry, "59"));
                                objclsCommon.AddChooseFromList_WithQuery(oForm, CFL_SER, "", sbQuery.ToString(), "AbsEntry");
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("stSerNo", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            SAPbouiCOM.Item oItem = oForm.Items.Item("8");
                            oNewItem.Left = oItem.Left;
                            oNewItem.Top = oForm.Items.Item("22").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            SAPbouiCOM.StaticText oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStaticText.Caption = "Serial No";


                            oNewItem = oForm.Items.Add("U_SerNo", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("7");
                            oNewItem.Left = oItem.Left;
                            oNewItem.Top = oForm.Items.Item("22").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, "U_SerNo");

                            objclsCommon.AddChooseFromList(oForm, CFL_SER, "10000045");
                            oEdit.ChooseFromListUID = CFL_SER;
                            oEdit.ChooseFromListAlias = "DistNumber";

                            oNewItem = oForm.Items.Add("btTC", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                            oNewItem.Left = oItem.Left + oItem.Width + 10;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width * 2;
                            SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.Caption = "Traveller Card";
                        }

                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == CFL_SER)
                            {
                                oEdit = oForm.Items.Item("U_SerNo").Specific;
                                try
                                {
                                    oEdit.String = oDataTable.GetValue(CommonFields.DistNumber, 0).ToString();
                                }
                                catch { }
                            }
                        }


                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void GenerateEC()
        {
            SAPbobsCOM.ICustomerEquipmentCards customerEquipmentCard;
            customerEquipmentCard = (SAPbobsCOM.ICustomerEquipmentCards)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oCustomerEquipmentCards);
            customerEquipmentCard.ManufacturerSerialNum = "MSerNum";
            customerEquipmentCard.InternalSerialNum = "ISerNum";
            customerEquipmentCard.ItemCode = "10000";
            customerEquipmentCard.CustomerCode = "C00001";
            int iAdd = customerEquipmentCard.Add();
            if (iAdd != 0)
            {
                string errMessage = oCompany.GetLastErrorDescription();
                oApplication.SetStatusBarMessage(errMessage, BoMessageTime.bmt_Short, false);
            }
            else
            {
                oApplication.StatusBar.SetText("Equipment card created successfully", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }

        }

        #endregion
    }
}
