

Changed hitory:

- 2017-12-24
  Add a column 'Enable for Serivce Layer' in the grid of the packaging wizard.
