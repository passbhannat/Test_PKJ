﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMTPTesting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "echelon.techies@gmail.com";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sendMail();
        }

        public bool sendMail()
        {
            var dbconfig = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();
            string smpthost = dbconfig["SMTP:SMTP_Host"];
            string smptport = dbconfig["SMTP:SMTP_Port"];
            string frommail = dbconfig["SMTP:FromMail"];

            System.Net.Mail.MailMessage Email = new System.Net.Mail.MailMessage();

            string to = textBox1.Text;
            if (to != "")
            {
                Email.To.Add(to);
            }
            //if (cc != "")
            //{
            //    Email.CC.Add(cc);
            //}
            //if (bcc != "")
            //{
            //    Email.Bcc.Add(bcc);
            //}
            try
            {
                Email.Subject = "Test";
                Email.IsBodyHtml = true;
                Email.Body = "Test Body";

                SmtpClient smtpClient = new SmtpClient();
                Email.From = new System.Net.Mail.MailAddress(frommail);
                smtpClient.Host = smpthost;
                smtpClient.Port = int.Parse(smptport);
                smtpClient.UseDefaultCredentials = false;

                try
                {
                    smtpClient.Send(Email);
                }
                catch (SmtpFailedRecipientsException ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                }
            }
            catch (System.Net.Mail.SmtpException se)
            {
                MessageBox.Show(se.Message);
                return false;
            }
            return true;
        }

    }
}
