using General;
using System;
using System.Collections.Generic;
using System.Text;

namespace General.Classes
{
    class Connection
    {
        #region SAP Objects

        public static SAPbouiCOM.Application oApplication;
        public static SAPbobsCOM.Company oCompany;
        public static bool isLiceseExpired;
        public static string salt;

        #endregion

        #region Methods

        /// <summary>
        /// Connect to SAP application
        /// </summary>
        public void ConnectToSAPApplication()
        {
            try
            {
                SAPMain.logger.DebugFormat("> {0}", "ConnectToSAPApplication");
                string devConnectionString = string.Empty;
                try
                {
                    devConnectionString = Convert.ToString(Environment.GetCommandLineArgs().GetValue(1));
                }
                catch
                {
                    devConnectionString = "0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056";
                }
                var sboGuiApi = new SAPbouiCOM.SboGuiApi();
                sboGuiApi.Connect(devConnectionString);

                oApplication = sboGuiApi.GetApplication();
                oCompany = (SAPbobsCOM.Company)oApplication.Company.GetDICompany();
                oApplication.StatusBar.SetText("Addon connected successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Connect Application Error: " + ex.Message);
            }
        }

        #endregion
    }
}
