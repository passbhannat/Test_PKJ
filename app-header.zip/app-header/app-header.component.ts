import { Component,Input, OnInit  } from '@angular/core';
import { Common_Service } from '../common/common_service';  
import { Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css'],
  providers:[Common_Service],

})
export class AppHeaderComponent implements OnInit{

  @Input() public isUserLoggedIn: boolean;
  public user:Array<any>=[];
  public dbName;
  public userName;
  public userTypeCode;


  constructor(private _common_Service: Common_Service,private router: Router){

  }

  ngOnInit() {
    let ltuser=localStorage.getItem('currentuser');
    this.user=JSON.parse(ltuser);
    if(this.user==null)
    {
      return;
    }
    else{  
        this.userName=this.user[0].UserName;   
        this.dbName=this.user[0].DBName;
        this.userTypeCode=this.user[0].UserTypeCode;
    }
  }

  logOut=function(){
        localStorage.removeItem("currentuser");
        this.router.navigate(['./']);
  }
}


